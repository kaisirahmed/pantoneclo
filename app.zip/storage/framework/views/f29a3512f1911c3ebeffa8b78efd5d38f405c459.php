
<?php $__env->startSection('title','Checkout'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/responsive.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/checkout.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<?php echo $__env->make('layouts.partials.pagebanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="checkout_section">
  <div class="container">
    
      <div class="row">
        <div class="col-md-4 order-md-2 mb-4">
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Order Amount</span>
            <span class="badge badge-secondary badge-pill"><?php echo e($order->quantity); ?></span>
          </h4>
          <ul class="list-group mb-3">
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (USD)</span>
              <strong><?php echo e($order->total); ?></strong>
            </li>
          </ul>

          
        </div>


        <div class="col-md-8 order-md-1">
            <h4 class="mb-3">Payment</h4>
          <form class="needs-validation form-box" novalidate="" method="POST" action="<?php echo e(route('order.purchage')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="order_id" value="<?php echo e($order_id); ?>">
            <div class="d-block my-3">
                
                <div class="custom-control custom-radio">
                  <input id="cod" name="payment_method" value="COD" type="radio" class="custom-control-input" required>
                  <label class="custom-control-label" for="cod">COD(Cash On Delivery)</label>
                </div>
            </div>
            <hr class="mb-4">
            
            <a href="<?php echo e(route('cart')); ?>" class="btn btn-warning btn-sm">Pay Later</a>
            <button class="btn btn-primary btn-sm" type="submit">Pay Now</button>
          </form>
        </div>
        

      <footer class="my-5 pt-5 text-muted text-center text-small">
      
      </footer>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('pantoneclo.ajax.checkout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('assets/js/checkout.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/payment.blade.php ENDPATH**/ ?>