
<?php $__env->startSection('title','Attributes Edit'); ?>
<?php $__env->startSection('content'); ?>
<?php echo Form::open([ 'method'=>'POST', 'route' => ['admin.attributes.update',$product->id], 'files' => true]); ?>

<?php echo csrf_field(); ?>
<div class="container page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h5 class="m-0"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a> /<a href="<?php echo e(route('admin.products.index')); ?>"> Products</a> / Attributes Edit</h5>
        <button type="submit" class="btn btn-success ml-1">Save<i class="material-icons">edit</i></button>
    </div>
</div>

<div class="container page__container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                
                <div class="card-header card-header-tabs-basic nav" role="tablist">
                    <a href="<?php echo e(route('admin.products.edit',$product->id)); ?>">Product Info</a>
                    <a href="#options" class="active" data-toggle="tab" role="tab" aria-controls="options" aria-selected="true">Attributes</a>
                    <a href="<?php echo e(route('admin.variations.edit',$product->id)); ?>">Variations</a>
                </div>
                <div class="card-body tab-content">
                    <div class="tab-pane active show fade" id="options">
                        <?php if($product->has_option): ?>
                            <?php $__currentLoopData = $product->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                <div class="card card-form">
                                    <div class="row no-gutters">
                                        
                                        <div class="col-lg-2 card-body">
                                            <p><strong class="headings-color"><?php echo e($option->name); ?> Attributes</strong></p>
                                            <p class="text-muted"></p>
                                        </div>
                                        <div class="col-lg-10 card-form__body card-body" id="<?php echo e(lcfirst($option->name)); ?>Option">
                                            
                                            <div class="form-row" id="#">
                                                <div class="col-12 col-md-6 mb-3">
                                                    <input type="text" name="options[<?php echo e(lcfirst($option->name)); ?>]" class="form-control" id="options_name" placeholder="Options Name" value="<?php echo e($option->name); ?>" readonly>
                                                </div>
                                                <div class="col-12 col-md-6 mb-3">
                                                    <button type="button" class="btn btn-outline-primary" id="<?php echo e(lcfirst($option->name)); ?>Add">+</button>
                                                </div>
                                            </div>
                                            <?php $__currentLoopData = $option->optionValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $optionValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                        
                                                <div class="form-row" id="<?php echo e(lcfirst($option->name)); ?>OptionSub">
                                                    <div class="col-12 col-md-6 mb-3">
                                                        <input type="text" name="<?php echo e(lcfirst($option->name)); ?><?php echo e($optionValue->id); ?>" class="form-control" id="<?php echo e(lcfirst($option->name)); ?>" value="<?php echo e($optionValue->value); ?>" placeholder="<?php echo e($option->name); ?>" readonly>
                                                    </div>
                                                    <div class="col-12 col-md-6 mb-3">
                                                        <button type="button" class="btn btn-outline-warning" id="<?php echo e(lcfirst($option->name)); ?>Sub" >-</button> <!--$key == 0 ? 'disabled' : ''-->
                                                    </div>
                                                    
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                        
                                        </div>
                                            
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(count($product->options) == 0): ?>
                        <div class="card card-form">
                            <div class="row no-gutters">
                                
                                <div class="col-lg-2 card-body">
                                    <p><strong class="headings-color">Size Attributes</strong></p>
                                    <p class="text-muted"></p>
                                </div>
                                <div class="col-lg-10 card-form__body card-body" id="sizeOption">
                                    
                                    <div class="form-row" id="#">
                                        <div class="col-12 col-md-6 mb-3">
                                            <input type="text" name="options[size]" class="form-control" id="options_name" placeholder="Options Name" value="Size" readonly>
                                        </div>
                                        <div class="col-12 col-md-6 mb-3">
                                            <button type="button" class="btn btn-outline-primary" id="sizeAdd">+</button>
                                        </div>
                                    </div>
                                    <div class="form-row" id="sizeOptionSub">
                                        <div class="col-12 col-md-6 mb-3">
                                            <input type="text" name="size" class="form-control" id="size" value="" placeholder="Size">
                                        </div>
                                        <div class="col-12 col-md-6 mb-3">
                                            <button type="button" class="btn btn-outline-warning" id="sizeSub" >-</button> <!--$key == 0 ? 'disabled' : ''-->
                                        </div>
                                        
                                    </div>
                                
                                </div>
                                    
                            </div>
                        </div>
                        <div class="card card-form">
                            <div class="row no-gutters">
                                
                                <div class="col-lg-2 card-body">
                                    <p><strong class="headings-color">Color Attributes</strong></p>
                                    <p class="text-muted"></p>
                                </div>
                                <div class="col-lg-10 card-form__body card-body" id="colorOption">
                                    
                                    <div class="form-row" id="#">
                                        <div class="col-12 col-md-6 mb-3">
                                            <input type="text" name="options[color]" class="form-control" id="options_name" placeholder="Options Name" value="Color" readonly>
                                        </div>
                                        <div class="col-12 col-md-6 mb-3">
                                            <button type="button" class="btn btn-outline-primary" id="colorAdd">+</button>
                                        </div>
                                    </div>
                                    <div class="form-row" id="colorOptionSub">
                                        <div class="col-12 col-md-6 mb-3">
                                            <input type="text" name="color" class="form-control" id="color" value="" placeholder="color">
                                        </div>
                                        <div class="col-12 col-md-6 mb-3">
                                            <button type="button" class="btn btn-outline-warning" id="colorSub" >-</button> <!--$key == 0 ? 'disabled' : ''-->
                                        </div>
                                        
                                    </div>
                                
                                </div>
                                    
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-success ml-1">Save<i class="material-icons">edit</i></button>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
    <!-- Range Slider -->
    <script src="<?php echo e(asset('admin/assets/vendor/ion.rangeSlider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/ion-rangeslider.js')); ?>"></script>

    <!-- jQuery Mask Plugin -->
    <script src="<?php echo e(asset('admin/assets/vendor/jquery.mask.min.js')); ?>"></script>

    <!-- Quill -->
    <script src="<?php echo e(asset('admin/assets/vendor/quill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/quill.js')); ?>"></script>

    <!-- Dropzone -->
    <script src="<?php echo e(asset('admin/assets/vendor/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/dropzone.js')); ?>"></script>

    <!-- Select2 -->
    <script src="<?php echo e(asset('admin/assets/vendor/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/select2.js')); ?>"></script>
    <script>

        $(document).ready(function() {
        
            $("#colorAdd").on('click', function(){
                $('#colorOption').append();
            })

            var maxField = 10; 
            var c = 1; var s = 1;
            $("#colorAdd").click(function () {
                newRowAdd = 
                '<div class="form-row" id="colorOptionSub">'+
                    '<div class="col-12 col-md-6 mb-3">'+
                        '<input type="text" name="color[]" class="form-control" id="color" placeholder="Color" value="" required="">'+
                    '</div>'+
                    '<div class="col-12 col-md-6 mb-3">'+
                        '<button type="button" class="btn btn-outline-warning" id="colorSub">-</button>'+
                    '</div>'+
                '</div>';
    
               
                if(c < maxField){ 
                    c++; //Increment field counter
                    $('#colorOption').append(newRowAdd);
                }
            });
    
            $("#colorOption").on("click", "#colorSub", function () {  
                $(this).parents("#colorOptionSub").remove();
                c--;
            })

            $("#sizeAdd").click(function () {  
                newRowAdd = 
                '<div class="form-row" id="sizeOptionSub">'+
                    '<div class="col-12 col-md-6 mb-3">'+
                        '<input type="text" name="size[]" class="form-control" id="size" placeholder="Size" value="" required="">'+
                    '</div>'+
                    '<div class="col-12 col-md-6 mb-3">'+
                        '<button type="button" class="btn btn-outline-warning" id="sizeSub">-</button>'+
                    '</div>'+
                '</div>';
    
               
                if(s < maxField){ 
                    s++; //Increment field counter
                    $('#sizeOption').append(newRowAdd);
                }
            });
    
            $("#sizeOption").on("click", "#sizeSub", function () {  
                $(this).parents("#sizeOptionSub").remove();
                s--;
            })
         
        });
        
           
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/attributes/edit.blade.php ENDPATH**/ ?>