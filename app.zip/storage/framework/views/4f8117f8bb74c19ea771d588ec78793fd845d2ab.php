<div id="commonModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="commonModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal-standard-title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div> <!-- // END .modal-header -->
            <div class="modal-body">
                
            </div> <!-- // END .modal-body -->
            <div class="modal-footer">
                <strong class="modal-success"></strong>
                <strong class="modal-danger"></strong>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div> <!-- // END .modal-footer -->
        </div> <!-- // END .modal-content -->
    </div> <!-- // END .modal-dialog -->
</div> <!-- // END .modal --><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/ajax/modal.blade.php ENDPATH**/ ?>