
<?php $__env->startSection('title','Address'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/responsive.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/account.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/header.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<!-- Page Header Start -->
<?php echo $__env->make('layouts.partials.pagebanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('pantoneclo.account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main class="col-md-9">
                <article>
                    
                    <div class="table-responsive">
                        
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <td>Name</td>
                                    <td>Email</td>
                                    <td>Street</td>
                                    <td>City</td>
                                    <td>State</td>
                                    <td>Country</td>
                                    <td>Zip</td>
                                    <td>Type</td>
                                    <td>Action</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="background-color: <?php echo e($address->is_default == 1 ? 'azure' : 'none'); ?>">
                                    <td><?php echo e($address->first_name." ".$address->last_name); ?></td>
                                    <td><?php echo e($address->email); ?></td>
                                    <td><?php echo e($address->street.' '.$address->street2); ?></td>
                                    <td><?php echo e($address->city_id != 0 ? $address->city->name : ''); ?></td>
                                    <td><?php echo e($address->state_id != 0 ? $address->state->name : ''); ?></td>
                                    <td><?php echo e($address->country_id != 0 ? $address->country->name : ''); ?></td>
                                    <td><?php echo e($address->zip); ?></td>
                                    <td><?php echo e($address->type == 0 ? 'Billing/Shipping' : ($address->type == 1 ? 'Billing' : 'Shipping')); ?></td>
                                    <td><a href="<?php echo e(route('account.address.edit',$address->id)); ?>" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i></a>&nbsp; 
                                        <a class="btn btn-outline-danger btn-sm" href="javascript:;" onclick="confirmDelete('<?php echo e($address->id); ?>')"><i class="fa fa-trash"></i></a>
                                        <form id="delete<?php echo e($address->id); ?>" action="<?php echo e(route('account.address.destroy', $address->id)); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($addresses->links()); ?>

                    </div> <!-- table-responsive .end// -->
                    <a href="<?php echo e(route('account.address.create')); ?>" class="btn btn-primary" >Add New</a>
                </article> <!-- card order-item .// -->
                
                
            </main> <!-- col.// -->
        </div>
    </div>
</section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/account/address.blade.php ENDPATH**/ ?>