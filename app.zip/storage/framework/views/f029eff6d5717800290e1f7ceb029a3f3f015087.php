<div class="container-fluid bg-dark p-0">
    <div class="row gx-0 d-none d-lg-flex">
        <div class="col-lg-7 px-5 text-start">
            <div class="h-100 d-inline-flex align-items-center me-4">
                <small class="text-white">PANTONECLO® Apparel B2B Solution for EU</small>
            </div>
        </div>
        <div class="col-lg-5 px-5 text-end">
            <div class="h-100 d-inline-flex align-items-center me-4">
                <small class="fa fa-phone-alt text-secondary me-2"></small>
                <small class="text-white">+386 307 96092</small>
            </div>
            <div class="h-100 d-inline-flex align-items-center mx-n2">
                <a class="btn btn-square btn-link rounded-0 border-0 border-secondary" href=""><i
                        class="fab fa-google"></i></a>

            </div>
        </div>
    </div>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/topbar.blade.php ENDPATH**/ ?>