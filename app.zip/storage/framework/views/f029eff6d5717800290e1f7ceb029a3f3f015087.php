<div class="top_bar">
    <div class="container">
        <div class="row">
            <div class="col d-flex flex-row">
                <div class="top_bar_contact_item"><div class="top_bar_icon"><img src="<?php echo e(asset('assets/images/phone.png')); ?>" alt=""></div><a href="callto:+386 30 796 092">PANTONECLO® Apparel </a></div>
                <div class="top_bar_contact_item"><div class="top_bar_icon"><img src="<?php echo e(asset('assets/images/mail.png')); ?>" alt=""></div><a href="mailto:info@pantoneclo.com">info@pantoneclo.com</a></div>

                
                
                <div class="top_bar_menu ml-auto">

                    <div class="top_bar_menu">
                        <ul class="standard_dropdown top_bar_dropdown">
                            <li>
                                <a href="#">English<i class="fas fa-chevron-down"></i></a>
                                
                            </li>
                            <li>
                                <a href="#">$ US dollar<i class="fas fa-chevron-down"></i></a>
                                
                            </li>
                        </ul>
                    </div>
                    <div class="top_bar_user">
                        <div class="user_icon"><img src="<?php echo e(asset('assets/images/user.svg')); ?>" alt=""></div>
                        <div><a href="<?php echo e(auth()->check() ? route('account') : route('register')); ?>"><?php echo e(auth()->check() ? Auth::user()->name : "Register"); ?></a></div>
                        <div><a href="<?php echo e(auth()->check() ? route('logout') : route('login')); ?>" <?php if(auth()->check()): ?> onclick="event.preventDefault(); document.getElementById('frm-logout').submit();" <?php endif; ?>><?php echo e(auth()->check() ? "Sign out" : "Sign in"); ?></a></div>
                        <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>		
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/topbar.blade.php ENDPATH**/ ?>