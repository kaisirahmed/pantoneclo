
<?php $__env->startSection('title', 'Files'); ?>
<?php $__env->startSection('routes'); ?>
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo Form::open([ 'method'=>'POST', 'route' => ['admin.files.store'], 'files' => true , 'class' => 'custom-validation']); ?>

    <?php echo csrf_field(); ?>
<div class="container-fluid page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h4 class="m-0">Files</h4>
        <button type="submit" class="btn btn-success ml-1">Save <i class="material-icons">account_circle</i></button>
    </div>
</div>
<div class="container page__container">
    <div class="card card-form">
        <div class="row no-gutters">
            <div class="container-fluid ">
                <div class="page__heading d-flex align-items-center justify-content-between">
                    <input type="file" name="files[]" class="btn btn-light" multiple>
                    <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-soft-warning d-flex align-items-center card-margin" role="alert">
                        <i class="material-icons mr-3">error_outline</i>
                        <div class="text-body">
                            <?php echo e($message); ?>

                        </div>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if(Session::has('limit')): ?>
                    <div class="alert alert-soft-warning d-flex align-items-center card-margin" role="alert">
                        <i class="material-icons mr-3">error_outline</i>
                        <div class="text-body">
                            <?php echo e(Session::get('limit')); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-12 card-form__body">

                <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-category-name","js-lists-values-parent-name"]'>                  
                    <div class="search-form search-form--light m-3">
                        <input type="text" class="form-control search" placeholder="Search">
                        <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                    </div>
                    <table class="table mb-0 thead-border-top-0">
                        <thead class="bg-black">
                            <tr>

                                <th style="width: 18px;">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#staff" id="customCheckAll">
                                        <label class="custom-control-label" for="customCheckAll"><span class="text-hide">Toggle all</span></label>
                                    </div>
                                    
                                </th>
                                 
                                <th>File</th> 
                                <th>
                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-file-name">Name</a>
                                </th> 
                                <th>Size</th> 
                                <th>Link</th> 
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="list" id="staff">
                            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-check-selected-row" id="file-check" value="asdfsdafsd">
                                        <label class="custom-control-label" for="product-check"><span class="text-hide">Check</span></label>
                                    </div>
                                </td>
                                <td><img width="50px" src="<?php echo e(asset($file->file)); ?>" alt="#"></td>
                                <td>

                                    <div class="media align-items-center">
                                        
                                        <div class="media-body">
                                            
                                            <span class="js-lists-values-file-name"><?php echo e($file->name); ?></span>

                                        </div>
                                    </div>

                                </td>
                                <td><?php echo e($file->size); ?></td>
                                <td>
                                    <span style="display:none" id="<?php echo e($file->id); ?>"><?php echo e(asset($file->file)); ?></span>
                                    <button type="button" class="btn btn-light" onclick="copyToClipboard('<?php echo e($file->id); ?>')">
                                        <i class="material-icons">link</i>
                                    </button>
                                </td>
                                
                                
                                <td>
                                    <button class="btn btn-danger btn-sm" type="button" onclick="confirmDelete('<?php echo e($file->id); ?>')"><i class="material-icons">delete</i></button>
                                    <form id="delete<?php echo e($file->id); ?>" action="<?php echo e(route('admin.files.destroy', $file->id)); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('DELETE')); ?>

                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="card-body text-center">
                        <?php echo e($files->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php echo e(Form::close()); ?>        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <!-- List.js -->
  <script src="<?php echo e(asset('admin/assets/vendor/list.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/list.js')); ?>"></script>
  <script>
    function copyToClipboard(elementId) {

        // Create a "hidden" input
        var aux = document.createElement("input");

        // Assign it the value of the specified element
        aux.setAttribute("value", document.getElementById(elementId).innerHTML);

        // Append it to the body
        document.body.appendChild(aux);

        // Highlight its content
        aux.select();

        // Copy the highlighted text
        document.execCommand("copy");

        // Remove it from the body
        document.body.removeChild(aux);

        toastr.success('Link Copied');

    }
     
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/files/index.blade.php ENDPATH**/ ?>