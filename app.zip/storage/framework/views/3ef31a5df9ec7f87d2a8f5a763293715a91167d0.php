
<?php $__env->startSection('title','Account'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/responsive.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/account.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/header.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<!-- Page Header Start -->
<?php echo $__env->make('layouts.partials.pagebanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y">
    <div class="container">
    
    <div class="row">
        <?php echo $__env->make('pantoneclo.account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="col-md-9">
    
            <article class="card mb-3">
                <div class="card-body">
                    
                    <figure class="icontext">
                            <div class="icon">
                                <img class="rounded-circle img-sm border" src="<?php echo e(asset('assets/images/user.png')); ?>">
                            </div>
                            <div class="text">
                                <strong class="account-name"><?php echo e($user->name); ?></strong> <br> 
                                <p class="mb-1 account-email"> <?php echo e($user->email); ?> </p> 
                                <p class="mb-1 account-phone"> <?php echo e($user->phone); ?> </p> 
                                <a href="#" class="btn btn-light btn-sm editUser" user-id="<?php echo e($user->id); ?>">Edit</a>
                            </div>
                    </figure>
                    <hr>
                    <p>
                        <i class="fa fa-map-marker text-muted"></i> &nbsp; My address:  
                         <br>
                        <span><?php echo e(count($addresses) > 0 ? $user->address->street .", ".$user->address->street2.", ".$user->address->state->name.", ".($user->address->city != 0 ? $user->address->city->name : '')." ".$user->address->country->name : 'Not Added Yet'); ?></span>
                        <a href="#" class="btn-link"> Edit</a>
                    </p>
    
                    
    
                    <article class="card-group card-stat">
                        <figure class="card bg">
                            <div class="p-3">
                                 <h4 class="title"><?php echo e($totalOrders); ?></h4>
                                <span>Orders</span>
                            </div>
                        </figure>
                        <figure class="card bg">
                            <div class="p-3">
                                 <h4 class="title"><?php echo e($paymentOrders); ?></h4>
                                <span>Payment</span>
                            </div>
                        </figure>
                        <figure class="card bg">
                            <div class="p-3">
                                 <h4 class="title"><?php echo e($awaitingDeliveryOrders); ?></h4>
                                <span>Awaiting delivery</span>
                            </div>
                        </figure>
                        <figure class="card bg">
                            <div class="p-3">
                                 <h4 class="title"><?php echo e($shippedOrders); ?></h4>
                                <span>Delivered items</span>
                            </div>
                        </figure>
                    </article>
                    
    
                </div> <!-- card-body .// -->
            </article> <!-- card.// -->
    
            <article class="card  mb-3">
                <div class="card-body">
                    <h5 class="card-title mb-4">Last orders </h5>	
    
                    <div class="row">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <figure class="itemside mb-3">
                                    <div class="aside"><img src="<?php echo e($item->product->image); ?>" class="border img-sm"></div>
                                    <figcaption class="info">
                                        <span><?php echo e($item->size ? $item->size : ''); ?></span>
                                        <span><?php echo e($item->color ? $item->color : ''); ?></span>
                                        <a href="<?php echo e(route('product.show',$item->product->slug)); ?>" tabindex="0"><p><?php echo e($item->product->name); ?></p></a>
                                        <span class="text-success"><?php echo e(config('orderstatus.'.$order->status)); ?></span>
                                    </figcaption>
                                </figure>
                            </div> <!-- col.// -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- row.// -->
    
                    <a href="<?php echo e(route('account.orders')); ?>" class="btn btn-outline-primary btn-block"> See all orders <i class="fa fa-chevron-down"></i>  </a>
                </div> <!-- card-body .// -->
            </article> <!-- card.// -->
    
        </main> <!-- col.// -->
    </div>
    
    </div> <!-- container .//  -->
    </section>
    <!-- ========================= SECTION CONTENT END// ========================= -->  
        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('pantoneclo.ajax.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/account.blade.php ENDPATH**/ ?>