
<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('content'); ?>
 
<div class="container-fluid page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h5 class="m-0"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a> / Categories</h5>
    </div>
</div>
<div class="container page__container">
    <div class="card card-form">
        <div class="row no-gutters">
            
            <div class="col-lg-12 card-form__body">


                <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-category-name","js-lists-values-parent-name"]'>
                    <div class="search-form search-form--light m-3">
                        <input type="text" class="form-control search" placeholder="Search">
                        <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                    </div>
                    <table class="table mb-0 thead-border-top-0">
                        <thead class="bg-black">
                            <tr>

                                <th style="width: 18px;">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#staff" id="customCheckAll">
                                        <label class="custom-control-label" for="customCheckAll"><span class="text-hide">Toggle all</span></label>
                                    </div>
                                    
                                </th>
                                <th>
                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-category-name">Name</a>
                                </th>
                                <th>
                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-parent-name">Parent</a>
                                </th>
                                
                                <th>Order No.</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="list" id="staff">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_1" value="<?php echo e($category->id); ?>">
                                        <label class="custom-control-label" for="customCheck1_1"><span class="text-hide">Check</span></label>
                                    </div>
                                </td>

                                <td>

                                    <div class="media align-items-center">
                                        
                                        <div class="media-body">
                                            
                                            <span class="js-lists-values-category-name"><?php echo e($category->name); ?></span>

                                        </div>
                                    </div>

                                </td>
                                <td>
                                    <span class="js-lists-values-parent-name">
                                        <?php if(count($category->parent()->get()) > 0): ?>
                                        <?php echo e(implode(', ', $category->parent()->get()->pluck('name')->toArray())); ?>

                                        <?php else: ?>
                                        <i class="ti-help-alt" title="No sub category to show"></i> 
                                        <?php endif; ?>
                                    </span>
                                    
                                </td>
                                <td><small class="text-muted"><?php echo e($category->order_no); ?></small></td>
                                <td><span class="badge badge-<?php echo e($category->status === 1 ? 'success' : 'warning'); ?>"><?php echo e($category->status === 1 ? 'Active' : 'Draft'); ?></span></td>
                                
                                
                                <td>
                                    <div class="dropdown ml-auto">
                                        <a href="javascript:void(0)" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown" aria-expanded="false">
                                            <i class="material-icons">more_vert</i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right" style="display: none;">
                                            <a class="dropdown-item text-warning" href="<?php echo e(route('admin.categories.edit', $category->id)); ?>"><i class="material-icons">edit</i> Edit</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item text-success" href="<?php echo e(route('admin.categories.show', $category->id)); ?>"><i class="material-icons">view_list</i> View</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item text-danger" href="#" type="submit" onclick="confirmDelete('<?php echo e($category->id); ?>')"><i class="material-icons">delete</i> Delete</a>
                                            <form id="delete<?php echo e($category->id); ?>" action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo e(method_field('DELETE')); ?>

                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>

</div>
        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <!-- List.js -->
  <script src="<?php echo e(asset('admin/assets/vendor/list.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/list.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/category/index.blade.php ENDPATH**/ ?>