
<?php $__env->startSection('title',$slug); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/jquery-ui-1.12.1.custom/jquery-ui.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/shop_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/shop_responsive.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<!-- Page Header Start -->
<?php echo $__env->make('layouts.partials.pagebanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Shop -->

<div class="shop">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">

                <!-- Shop Sidebar -->
                <div class="shop_sidebar">
                    <div class="sidebar_section">
                        <div class="sidebar_title">Categories</div>
                        <ul class="sidebar_categories">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('category.products',$category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="sidebar_section filter_by_section">
                        <div class="sidebar_title">Filter By</div>
                        <div class="sidebar_subtitle">Price</div>
                        <div class="filter_price">
                            <div id="slider-range" class="slider_range"></div>
                            <p>Range: </p>
                            <p><input type="text" id="amount" class="amount" readonly style="border:0; font-weight:bold;"></p>
                        </div>
                    </div>
                    
                    
                </div>

            </div>

            <div class="col-lg-9">
                
                <!-- Shop Content -->

                <div class="shop_content">
                    <div class="shop_bar clearfix">
                        <div class="shop_product_count"><span><?php echo e(count($products)); ?></span> products found</div>
                        <div class="shop_sorting">
                            <span>Sort by:</span>
                            <ul>
                                <li>
                                    <span class="sorting_text">Highest rated<i class="fa fa-chevron-down"></span></i>
                                    <ul>
                                        <li class="shop_sorting_button" data-isotope-option='{ "sortBy": "original-order" }'>Highest rated</li>
                                        <li class="shop_sorting_button" data-isotope-option='{ "sortBy": "name" }'>Name</li>
                                        <li class="shop_sorting_button"data-isotope-option='{ "sortBy": "price" }'>Price</li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="product_grid">
                        <div class="product_grid_border"></div>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Product Item -->
                        <div class="product_item discount">
                            
                            
                            <div class="product_image d-flex flex-column align-items-center justify-content-center"><img src="<?php echo e($product->image); ?>" alt=""></div>
                            <a href="<?php echo e(route('product.show',$product->slug)); ?>" tabindex="0">
                                <div class="product_content">
                                    <div class="product_price">&#36;<?php echo e($product->sale_price); ?><span>&#36;<?php echo e($product->price); ?></span></div>
                                    <div class="product_name"><p><?php echo e(mb_strimwidth($product->name,0,30,"...")); ?></p></div>
                                </div>
                            </a>
                            <div class="product_fav"><i class="fa fa-heart"></i></div>
                            <ul class="product_marks">
                                <?php if($product->discount_amount != 0): ?>
                                    <li class="product_mark product_discount">-<?php echo e($product->discount_amount); ?>$</li>
                                <?php elseif($product->discount_percentage !=0): ?>
                                    <li class="product_mark product_discount">-<?php echo e($product->discount_percentage); ?>%</li>
                                <?php endif; ?>
                                <li class="product_mark product_new">new</li>
                            </ul>
                            <div class="product_extras">
                                <a href="<?php echo e(route('product.show',$product->slug)); ?>"><button class="product_cart_button" tabindex="0">Details</button></a>
                            </div>
                            
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Shop Page Navigation -->

                    <div class="shop_page_nav d-flex flex-row">
                        <?php echo $products->links(); ?>

                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/plugins/Isotope/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-ui-1.12.1.custom/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/parallax-js-master/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/shop_custom.js')); ?>"></script>
<?php echo $__env->make('pantoneclo.ajax.addToCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/categoryshop.blade.php ENDPATH**/ ?>