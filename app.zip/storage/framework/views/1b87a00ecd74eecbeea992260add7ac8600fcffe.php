
<?php $__env->startSection('title','Address Create'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/responsive.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/account.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/header.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<!-- Page Header Start -->
<?php echo $__env->make('layouts.partials.pagebanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('pantoneclo.account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main class="col-md-9 order-md-1">
                <h4 class="mb-3">Address</h4>
                <form class="needs-validation form-box" novalidate="" method="POST" action="<?php echo e(route('account.address.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="firstName">First name</label>
                            <input type="text" name="first_name" class="form-control" id="firstName" placeholder="" value="<?php echo e(old('first_name')); ?>" required>
                            <div class="invalid-feedback">
                            Valid first name is required.
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="lastName">Last name</label>
                            <input type="text" name="last_name" class="form-control" id="lastName" placeholder="" value="<?php echo e(old('last_name')); ?>" required>
                            <div class="invalid-feedback">
                            Valid last name is required.
                            </div>
                        </div>
                    </div>
        
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control" id="email" placeholder="you@email.com" value="<?php echo e(old('email')); ?>">
                            <div class="invalid-feedback">
                            Please enter a valid email address for shipping updates.
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone">Mobile</label>
                            <input type="text" name="mobile" class="form-control" id="phone" placeholder="+xxx-xxxxxxx" value="<?php echo e(old('mobile')); ?>" required>
                            <div class="invalid-feedback">
                            Valid phone is required.
                            </div>
                        </div>
                    </div>
                
                    <div class="mb-3">
                        <label for="street">Street</label>
                        <input type="text" name="street" class="form-control" id="street" placeholder="" value="<?php echo e(old('street')); ?>" required>
                        <div class="invalid-feedback">
                            Please enter your street.
                        </div>
                    </div>
        
                    <div class="mb-3">
                    
                    <input type="text" name="street2" class="form-control" id="street2" placeholder="" value="<?php echo e(old('street2')); ?>">
                    </div>
        
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="country">Country</label>
                            <select class="custom-select d-block w-100" name="country_id" id="billing_country" required>
                            <option value="">Choose...</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">
                            Please select a valid country.
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="state">State</label>
                            <select class="custom-select d-block w-100" name="state_id" id="billing_state">
                            <option value="0">Choose...</option>
                            </select>
                            <div class="invalid-feedback">
                            Please provide a valid state.
                            </div>
                        </div>
                    
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="state">City</label>
                            <select class="custom-select d-block w-100" name="city_id" id="billing_city" >
                            <option value="0">Choose...</option>
                            </select>
                            <div class="invalid-feedback">
                            Please provide a valid state.
                            </div>
                        </div>
            
                        <div class="col-md-6 mb-3">
                            <label for="zip">Zip</label>
                            <input type="text" class="form-control" name="zip" id="billing_zip" placeholder="" value="<?php echo e(old('zip')); ?>" required>
                            <div class="invalid-feedback">
                            Zip code required.
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="state">Type</label>
                            <select class="custom-select d-block w-100" name="type" >
                                <option value="0">Billing/Shipping</option>
                                <option value="1">Billing</option>
                                <option value="2">Shipping</option>
                            </select>
                            <div class="invalid-feedback">
                            Please provide a valid Type.
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="default">Default</label>
                            <br>
                            <input type="checkbox" value="1" name="is_default">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <br>
                           <button class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </div>
            </main> <!-- col.// -->
        </div>
    </div>
</section>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('pantoneclo.ajax.checkout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/account/addressCreate.blade.php ENDPATH**/ ?>