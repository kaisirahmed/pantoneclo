<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($order->user->name); ?>,

Thank you for ordering from Pantoneclo!

We are excited for you to receive your order <?php echo e($order->order_number); ?> <br>
and will notify you once its on its way. If you have ordered from <br>
multiple sellers, your items will be delivered in separate packages.<br> 
We hope you had a great shopping experience! <br>
You can check your order status here.

<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Larry</td>
      <td>the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>

Thanks,<br>
Pantoneclo
<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/emails/placeorder.blade.php ENDPATH**/ ?>