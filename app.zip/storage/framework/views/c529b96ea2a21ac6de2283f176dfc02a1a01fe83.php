<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($order->user->name); ?>,

Thank you for ordering from Pantoneclo!

We are excited for you to receive your order #<?php echo e($order->order_number); ?> <br>
and will notify you once its on its way. If you have ordered from <br>
multiple sellers, your items will be delivered in separate packages.<br> 
We hope you had a great shopping experience! <br>
You can check your order status here.

Please note, we are unable to change your delivery address once your order is placed.​<br>
Here's a confirmation of what you bought in your order.

<h3>Delivery Details</h3>
<table class="table table-striped">
    <tr>
        <td>Name: </td>
        <td><?php echo e($order->shipping()->name); ?></td>
    </tr>
    <tr>
        <td>Address: </td>
        <td><?php echo e($order->shipping()->street); ?>, <?php echo e($order->shipping()->street2); ?>, <?php echo e(($order->shipping()->city != 0 ? $order->shipping()->city->name : '')); ?>, <?php echo e($order->shipping()->state->name); ?>, <?php echo e($order->shipping()->country->name); ?></td>
    </tr>
    <tr>
        <td>Phone: </td>
        <td><?php echo e($order->shipping()->phone); ?></td>
    </tr>
    <tr>
        <td>Email: </td>
        <td><?php echo e($order->shipping()->email); ?></td>
    </tr>
</table>

<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Image</th>
      <th scope="col">Name</th>
      <th scope="col">Size|Color</th>
      <th scope="col">Quantity|Price</th>
      <th scope="col">Price</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($key+1); ?></th>
      <td><img width="40" src="<?php echo e($item->product->image); ?>"></td>
      <td><?php echo e($item->product->name); ?></td>
      <td><?php echo e($item->variation); ?></td>
      <td><?php echo e($item->quantity); ?>*<?php echo e($item->product_price); ?></td>
      <td><?php echo e($item->total_price); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td>Total</td>
    <td><?php echo e($order->total); ?></td>
  </tfoot>
</table>

Thanks,<br>
Pantoneclo
<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/emails/placeorder.blade.php ENDPATH**/ ?>