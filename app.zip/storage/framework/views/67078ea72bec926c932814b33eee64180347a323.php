<meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description"><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/meta.blade.php ENDPATH**/ ?>