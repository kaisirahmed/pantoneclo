<div class="banner_2">
    
 
      
    
        <video style="margin-top: -18px;" width="100%" height="1000" autoplay muted playsinline>
            <source src="<?php echo e(asset('assets/videos/pantoneclo.mp4')); ?>" type="video/mp4">
        </video>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/slider.blade.php ENDPATH**/ ?>