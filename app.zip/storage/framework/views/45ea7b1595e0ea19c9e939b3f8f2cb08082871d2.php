

            <!-- Logo -->
            

            <!-- Search -->
            

            <!-- Wishlist -->
            

                    <!-- Cart -->
                    <?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/headermain.blade.php ENDPATH**/ ?>