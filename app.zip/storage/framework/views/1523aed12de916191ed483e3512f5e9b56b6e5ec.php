<div class="container-fluid bg-light overflow-hidden px-lg-0">
    <div class="container px-lg-0">
        <div class="row g-0 mx-lg-0 ">
            <div class="col-lg-6 ps-lg-0 wow fadeIn" data-wow-delay="0.1s" style="min-height: 400px;">
                <div class="h-100 d-flex align-items-center">
                    <h1 class="mb-4">Company details:</h1>
                </div>
            </div>
            <div class="col-lg-6 about-text py-5 wow fadeIn" data-wow-delay="0.5s">
                <div class="p-lg-5 pe-lg-0">

                    <p><i class="fa fa-check-circle text-primary me-3"></i>Matrix Design d.o.o.</p>
                    <p><i class="fa fa-check-circle text-primary me-3"></i>Pokopališka 4, 3000 Celje, Slovenia</p>
                    <p><i class="fa fa-check-circle text-primary me-3"></i> Reg No: 8878153000 </p>
                    <p><i class="fa fa-check-circle text-primary me-3"></i> EORI NO: SI66403618 </p>
                    <p><i class="fa fa-check-circle text-primary me-3"></i> Tax No: 66403618 </p>
                    <p><i class="fa fa-check-circle text-primary me-3"></i> VAT No: SI66403618 </p>
                    <p><i class="fa fa-check-circle text-primary me-3"></i> Tax No: 66403618 </p>
                    <p><i class="fa fa-check-circle text-primary me-3"></i> PANTONECLO® mark under European Union
                        Intellectual property
                        Office 018641390 </p>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/about.blade.php ENDPATH**/ ?>