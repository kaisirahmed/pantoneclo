
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/responsive.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/popupvideo.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<!-- Carousel Start -->
<?php echo $__env->make('layouts.partials.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Carousel End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Deals of the week -->


<!-- Reviews -->



<!-- Adverts -->

<?php echo $__env->make('layouts.partials.adverts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Characteristics -->

<?php echo $__env->make('layouts.partials.characteristics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Trends -->
<?php if(count($trending) > 0): ?>
<?php echo $__env->make('layouts.partials.trends', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<!-- Popular Categories -->

<?php echo $__env->make('layouts.partials.popularcategories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Banner -->



<!-- Hot New Arrivals -->



<!-- Best Sellers -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.js"></script>
<script>
$(function() {
  // CLOSE AND REMOVE ON ESC
  $(document).on('keyup',function(e) {
    if (e.keyCode == 27) {
      $('.overlay').remove();
    }
  });
  
  // CLOSE AND REMOVE ON CLICK
  $('body').on('click','.overlay, .close', function() {
    $('.overlay').remove();
  });
  
  // SO PLAYING WITH THE VIDEO CONTROLS DOES NOT
  // CLOSE THE POPUP
  $('body').on('click','.videoBox', function(e) {
    e.stopPropagation();
  });

  $('video').on('ended', function () {
    this.load();
    this.play();
  });

});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/index.blade.php ENDPATH**/ ?>