
<?php $__env->startSection('title','Pentoneclo'); ?>
<?php $__env->startSection('content'); ?>
<!-- Carousel Start -->
<?php echo $__env->make('layouts.partials.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Carousel End -->

<!-- About Start -->

<!-- About End -->

<!-- Testimonial Start -->
<?php echo $__env->make('layouts.partials.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Testimonial End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/index.blade.php ENDPATH**/ ?>