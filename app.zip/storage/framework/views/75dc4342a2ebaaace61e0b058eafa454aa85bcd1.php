
<?php $__env->startSection('title','Pentoneclo'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/responsive.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<!-- Carousel Start -->
<?php echo $__env->make('layouts.partials.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Carousel End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Characteristics -->

<?php echo $__env->make('layouts.partials.characteristics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Deals of the week -->


<!-- Reviews -->



<!-- Adverts -->



<!-- Trends -->

<?php echo $__env->make('layouts.partials.trends', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Popular Categories -->

<?php echo $__env->make('layouts.partials.popularcategories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Banner -->



<!-- Hot New Arrivals -->



<!-- Best Sellers -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/index.blade.php ENDPATH**/ ?>