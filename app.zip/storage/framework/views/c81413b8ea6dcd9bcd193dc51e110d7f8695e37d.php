
<?php $__env->startSection('title','Checkout'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/responsive.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/checkout.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<?php echo $__env->make('layouts.partials.pagebanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="checkout_section">
  <div class="container">
    
      <div class="row">
        <div class="col-md-4 order-md-2 mb-4">
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Your Orders</span>
            <span class="badge badge-secondary badge-pill"><?php echo e($cartTotalQuantity); ?></span>
          </h4>
          <ul class="list-group mb-3">
            <table class="table" id="cartTable">
            <?php $__currentLoopData = $cartitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td style="vertical-align: middle;width: 30%;" align="left"><img width="50%" src="<?php echo e($item->attributes->image); ?>" alt=""></td>
                <td style="vertical-align: middle;width: 40%;" align="left"><?php echo e(mb_strimwidth($item->name,0,30,"...")); ?></td>
                <td style="vertical-align: middle"><?php echo e($item->attributes->variation); ?> | <?php echo e($item->quantity); ?></td>
                <td style="vertical-align: middle"><?php echo e($item->attributes->currency); ?><?php echo e($item->price); ?></td>
              </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (USD)</span>
              <strong><?php echo e($cartTotal); ?></strong>
            </li>
          </ul>

          <form class="card p-2">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Promo code">
              <div class="input-group-append">
                <button type="submit" class="btn btn-secondary">Redeem</button>
              </div>
            </div>
          </form>
        </div>


        <div class="col-md-8 order-md-1">
          <form class="needs-validation form-box" novalidate="" method="POST" action="<?php echo e(route('checkout.store')); ?>">
            <?php echo csrf_field(); ?>
          <?php if($user->billing() != null): ?>
          <div class="alert alert-soft-warning d-flex align-items-center card-margin" role="alert">
            <input type="checkbox" value="<?php echo e($user->billing()->id); ?>" name="billing_id" id="billingId">
            <div class="text-body">
              &nbsp;<?php echo e($user->billing() != null ? $user->billing()->street .", ".$user->billing()->street2.", ".$user->billing()->state->name.", ".($user->billing()->city != 0 ? $user->billing()->city->name : '')." ".$user->billing()->country->name : 'Not Added Yet'); ?>

            </div>
            <button class="btn btn-outline-primary btn-sm ml-auto" disabled>Billing Address</button>
          </div>
          <?php endif; ?>
          <?php if($user->shipping() != null): ?>
          <div class="alert alert-soft-warning d-flex align-items-center card-margin" role="alert">
            <input type="checkbox" value="<?php echo e($user->shipping()->id); ?>" name="shipping_id" id="shippingId">
            <div class="text-body">
              &nbsp;<?php echo e($user->shipping() != null ? $user->shipping()->street .", ".$user->shipping()->street2.", ".$user->shipping()->state->name.", ".($user->shipping()->city != 0 ? $user->shipping()->city->name : '')." ".$user->shipping()->country->name : 'Not Added Yet'); ?>

            </div>
            <button class="btn btn-outline-primary btn-sm ml-auto" disabled>Shipping Address</button>
          </div>
          <?php endif; ?>
          <h6 class="text-muted">If you want to add use new billing or shipping please fillup the fields. Otherwise set the default address automatically.</h6>
          <hr class="mb-4">
          <?php if($user->billing() != null && $user->shipping() != null): ?>
          <div class="custom-control custom-checkbox">
            <input type="checkbox" name="default_address" class="custom-control-input" id="default-address" value="1">
            <label class="custom-control-label" for="default-address"><b>Place order with default address</b></label>
          </div>
          <hr class="mb-4">
          <?php endif; ?>
          <div id="billing-address">
            <h5 class="mb-3">Billing Address</h5>
            
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" name="billing_first_name" class="form-control" id="billing_firstName" placeholder="" value="">
                <div class="invalid-feedback">
                  Valid first name is required.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" name="billing_last_name" class="form-control" id="billing_lastName" placeholder="" value="">
                <div class="invalid-feedback">
                  Valid last name is required.
                </div>
              </div>
            </div>

            
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="email">Email</label>
                <input type="email" name="billing_email" class="form-control" id="billing_email" placeholder="you@email.com">
                <div class="invalid-feedback">
                  Please enter a valid email address for shipping updates.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="phone">Mobile</span></label>
                <input type="text" name="billing_mobile" class="form-control" id="billing_mobile" placeholder="+xxx-xxxxxxx" value="">
                <div class="invalid-feedback">
                  Valid phone is required.
                </div>
              </div>
            </div>
         
            <div class="mb-3">
              <label for="street">Street</label>
              <input type="text" name="billing_street" class="form-control" id="billing_street" placeholder="">
              <div class="invalid-feedback">
                Please enter your street.
              </div>
            </div>

            <div class="mb-3">
              
              <input type="text" name="billing_street2" class="form-control" id="billing_street2" placeholder="">
            </div>

            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="country">Country</label>
                <select class="custom-select d-block w-100" name="billing_country_id" id="billing_country">
                  <option value="">Choose...</option>
                  <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="invalid-feedback">
                  Please select a valid country.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="state">State</label>
                <select class="custom-select d-block w-100" name="billing_state_id" id="billing_state">
                  <option value="0">Choose...</option>
                </select>
                <div class="invalid-feedback">
                  Please provide a valid state.
                </div>
              </div>
              
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="state">City</label>
                <select class="custom-select d-block w-100" name="billing_city_id" id="billing_city" >
                  <option value="0">Choose...</option>
                </select>
                <div class="invalid-feedback">
                  Please provide a valid state.
                </div>
              </div>

              <div class="col-md-6 mb-3">
                <label for="zip">Zip</label>
                <input type="text" class="form-control" name="billing_zip" id="billing_zip" placeholder="">
                <div class="invalid-feedback">
                  Zip code required.
                </div>
              </div>
            </div>
            <hr class="mb-4">
            <div class="custom-control custom-checkbox">
              <input type="checkbox" name="is_same" class="custom-control-input" id="same-address" value="1">
              <label class="custom-control-label" for="same-address">Shipping address is the same as my billing address</label>
            </div>
            

          <hr class="mb-4">
          
            <div class="shipping-address">
              <h5 class="mb-3">Shipping address</h5>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label for="firstName">First name</label>
                  <input type="text" name="shipping_first_name" class="form-control" id="shipping_first_name" placeholder="" value="">
                  <div class="invalid-feedback">
                    Valid first name is required.
                  </div>
                </div>
                <div class="col-md-6 mb-3">
                  <label for="lastName">Last name</label>
                  <input type="text" name="shipping_last_name" class="form-control" id="shipping_last_name" placeholder="" value="">
                  <div class="invalid-feedback">
                    Valid last name is required.
                  </div>
                </div>
              </div>

              
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label for="email">Email</label>
                  <input type="email" name="shipping_email" class="form-control" id="shipping_email" placeholder="">
                  <div class="invalid-feedback">
                    Please enter a valid email address for shipping updates.
                  </div>
                </div>
                <div class="col-md-6 mb-3">
                  <label for="phone">Phone <span class="text-muted">(Optional)</span></label>
                  <input type="text" name="shipping_mobile" class="form-control" id="shipping_mobile" placeholder="" value="">
                  <div class="invalid-feedback">
                    Valid phone is required.
                  </div>
                </div>
              </div>
          
              <div class="mb-3">
                <label for="street">Street</label>
                <input type="text" name="shipping_street" class="form-control" id="shipping_street" placeholder="1234 Main St">
                <div class="invalid-feedback">
                  Please enter your street.
                </div>
              </div>

              <div class="mb-3">
                
                <input type="text" name="shipping_street2" class="form-control" id="shipping_street2" placeholder="Apartment or suite">
              </div>

              <div class="row">
                <div class="col-md-6 mb-3">
                  <label for="country">Country</label>
                  <select class="custom-select d-block w-100" name="shipping_country_id" id="shipping_country">
                    <option value="">Choose...</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <div class="invalid-feedback">
                    Please select a valid country.
                  </div>
                </div>
                <div class="col-md-6 mb-3">
                  <label for="state">State</label>
                  <select class="custom-select d-block w-100" name="shipping_state_id" id="shipping_state">
                    <option value="">Choose...</option>
                  </select>
                  <div class="invalid-feedback">
                    Please provide a valid state.
                  </div>
                </div>
                
              </div>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label for="state">City</label>
                  <select class="custom-select d-block w-100" name="shipping_city_id" id="shipping_city" >
                    <option value="">Choose...</option>
                  </select>
                  <div class="invalid-feedback">
                    Please provide a valid state.
                  </div>
                </div>

                <div class="col-md-6 mb-3">
                  <label for="zip">Zip</label>
                  <input type="text" class="form-control" name="shipping_zip" id="shipping_zip" placeholder="">
                  <div class="invalid-feedback">
                    Zip code required.
                  </div>
                </div>
              </div>
              <hr class="mb-4">
            </div>  
          </div>
            <button class="btn btn-primary btn-sm" type="submit">Place Order</button>
          </form>
        </div>
        

      <footer class="my-5 pt-5 text-muted text-center text-small">
      
      </footer>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('pantoneclo.ajax.checkout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('assets/js/checkout.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/checkout.blade.php ENDPATH**/ ?>