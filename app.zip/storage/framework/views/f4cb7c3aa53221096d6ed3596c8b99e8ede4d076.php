<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<!-- Prevent the demo from appearing in search engines -->
<meta name="robots" content="noindex">
<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/components/meta/meta.blade.php ENDPATH**/ ?>