
<?php $__env->startSection('title','Account'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/responsive.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/account.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/header.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<!-- Page Header Start -->
<?php echo $__env->make('layouts.partials.pagebanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('pantoneclo.account.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main class="col-md-9">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <article class="card mb-4" id="printOrders<?php echo e($order->id); ?>">
                    <header class="card-header">
                        <a href="#" class="float-right" onclick="print('printOrders<?php echo e($order->id); ?>')"> <i class="fa fa-print"></i> Print</a>
                        <strong class="d-inline-block mr-3">Order ID: <?php echo e($order->order_number); ?></strong>
                        <span>Order Date: <?php echo e(date("d F, Y",strtotime($order->date))); ?></span>
                    </header>
                    <div class="card-body">
                        <div class="row"> 
                            <div class="col-md-8">
                                <h6 class="text-muted">Delivery to</h6>
                                <p><?php echo e($order->shipping->name); ?><br>  
                                Phone: <?php echo e($order->shipping->phone); ?> Email: <?php echo e($order->shipping->email); ?> <br>
                                Location: <?php echo e($order->shipping->street); ?>, <?php echo e($order->shipping->street2); ?>, <?php echo e(($order->shipping->city != 0 ? $order->shipping->city->name : '')); ?>, <?php echo e($order->shipping->state->name); ?>, <?php echo e($order->shipping->country->name); ?> <br> 
                                Zip Code: <?php echo e($order->shipping->zip); ?>

                                </p>
                            </div>
                            <div class="col-md-4">
                                <h6 class="text-muted">Payment</h6>
                                <span class="text-success">
                                    
                                    <i class="fab fa-fa-money" aria-hidden="true"></i>
                                    <?php echo e($order->payment_method); ?>

                                </span>
                                <p>Subtotal: <?php echo e($order->subtotal); ?> <br>
                                Shipping fee:  <?php echo e($order->shipping_charge); ?> <br> 
                                <span class="b">Total:  $<?php echo e($order->total); ?> </span>
                                </p>
                            </div>
                        </div> <!-- row.// -->
                    </div> <!-- card-body .// -->
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tbody>
                                <?php $__empty_2 = true; $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <tr>
                                    <td>
                                        <img width="65" src="<?php echo e($item->product->image); ?>" class="img-xs border">
                                    </td>
                                    <td> 
                                        <p class="title mb-0"><?php echo e($item->product->name); ?></p>
                                        <var class="price text-muted">USD <?php echo e($item->product->sale_price); ?></var>
                                    </td>
                                    <td> 
                                        <span><?php echo e($item->size ? $item->size : ''); ?></span>
                                        <span><?php echo e($item->color ? $item->color : ''); ?></span>
                                    </td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <h5>Not Found</h5>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div> <!-- table-responsive .end// -->
                </article> <!-- card order-item .// -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h5>Not Found</h5>
                <?php endif; ?>
                <?php echo e($orders->links()); ?>

            </main> <!-- col.// -->
        </div>
    </div>
</section>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    function print(id) {
        var divContents = document.getElementById(id).innerHTML;
        var a = window.open('', '', 'height=500, width=500');
        a.document.write('<html>');
        a.document.write('<body > <h1>Div contents are <br>');
        a.document.write(divContents);
        a.document.write('</body></html>');
        a.document.close();
        a.print();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/account/orders.blade.php ENDPATH**/ ?>