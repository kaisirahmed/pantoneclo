<div class="trends">
    <div class="trends_background" style="background-image:url(images/trends_background.jpg)"></div>
    <div class="trends_overlay"></div>
    <div class="container">
        <div class="row">

            <!-- Trends Content -->
            <div class="col-lg-3">
                <div class="trends_container">
                    <h2 class="trends_title">Trends 2022</h2>
                    <div class="trends_text"><p>Our tranding products</p></div>
                    <div class="trends_slider_nav">
                        <div class="trends_prev trends_nav"><i class="fa fa-angle-left ml-auto"></i></div>
                        <div class="trends_next trends_nav"><i class="fa fa-angle-right ml-auto"></i></div>
                    </div>
                </div>
            </div>

            <!-- Trends Slider -->
            <div class="col-lg-9">
                <div class="trends_slider_container">

                    <!-- Trends Slider -->

                    <div class="owl-carousel owl-theme trends_slider">
                        <?php $__currentLoopData = $trending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- Trends Slider Item -->
                        <div class="owl-item">
                            <div class="trends_item is_new">
                                <div class="trends_image d-flex flex-column align-items-center justify-content-center">
                                    <img src="<?php echo e($trend->image); ?>" alt="">
                                </div>
                                <div class="trends_content">
                                    <div class="trends_category"><a href="#"><?php echo e(implode(', ', $trend->categories()->pluck('name')->toArray())); ?></a></div>
                                    <div class="trends_info clearfix">
                                        <a href="<?php echo e(route('product.show',$trend->slug)); ?>"><div class="trends_name"><?php echo e(mb_strimwidth($trend->name,0,50,"...")); ?></div></a>
                                        <div class="trends_price">&#36;<?php echo e($trend->sale_price); ?><span></div>
                                    </div>
                                </div>
                                
                                <div class="trends_fav"><i class="fa fa-heart"></i></div>
                            </div>
                        </div>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/trends.blade.php ENDPATH**/ ?>