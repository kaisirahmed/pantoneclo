
<div class="container-fluid page-header py-5 mb-5">
    <div class="container py-5">
        <h1 class="display-4 text-white mb-3 text-center animated slideInDown">Welcome To Pantoneclo B2B Services
            All Collection
        </h1>
    </div>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/pageheader.blade.php ENDPATH**/ ?>