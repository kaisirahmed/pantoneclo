
<?php $__env->startSection('title',$product->name); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/product_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/product_responsive.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.ez-plus.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('banner'); ?>
<?php echo $__env->make('layouts.partials.pagebanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<!-- Single Product -->

<div class="single_product">
    <div class="container">
        <div class="row">

            <!-- Images -->
            <div class="col-lg-1 order-lg-1 order-2">
                <ul class="image_list" id="product_gallery">
                    <li data-image="<?php echo e($product->has_option ? $product->variant()->image : $product->front_side_image); ?>" data-zoom-image="<?php echo e($product->has_option ? $product->variant()->image : $product->front_side_image); ?>">
                        <img src="<?php echo e($product->front_side_image); ?>" alt=""/>
                    </li>
                    <li data-image="<?php echo e($product->back_side_image); ?>" data-zoom-image="<?php echo e($product->back_side_image); ?>">
                        <img src="<?php echo e($product->back_side_image); ?>" alt="">
                    </li>
                    <li data-image="<?php echo e($product->left_side_image); ?>" data-zoom-image="<?php echo e($product->left_side_image); ?>">
                        <img src="<?php echo e($product->left_side_image); ?>" alt="">
                    </li>
                    <li data-image="<?php echo e($product->right_side_image); ?>" data-zoom-image="<?php echo e($product->right_side_image); ?>">
                        <img src="<?php echo e($product->right_side_image); ?>" alt="">
                    </li>
                    <li data-image="<?php echo e($product->image); ?>" data-zoom-image="<?php echo e($product->image); ?>">
                        <img src="<?php echo e($product->image); ?>" alt="">
                    </li>
                </ul>
            </div>

            <!-- Selected Image -->
            <div class="col-lg-5 order-lg-2 order-1">
                <div class="image_selected">
                    <img id="product_zoom" style="height: 100%; width: 100%; object-fit: contain" src="<?php echo e($product->image); ?>" data-zoom-image="<?php echo e($product->image); ?>"/>
                </div>
            </div>            
            <!-- Description -->
            <div class="col-lg-6 order-3">
                <div class="product_description">
                    <div class="product_category"><?php echo e(implode(', ', $product->categories()->pluck('name')->toArray())); ?></div>
                    <div class="product_name"><?php echo e($product->name); ?></div>
                    <div class="rating_r rating_r_4 product_rating"><i></i><i></i><i></i><i></i><i></i></div>
                    <div class="product_price discount">&#36;<?php echo e($product->sale_price); ?> </div>
                    <span> &#36;<?php echo e($product->price); ?> (<?php echo e($product->discount_amount != 0 ? $product->discount_amount : $product->discount_percentage); ?>&#37; off)</span>
                    <div class="product_text"><p><?php echo $product->description; ?></p></div>
                    <div class="order_info d-flex flex-row">
                        <form action="#" id="productForm">
                            <div class="clearfix" style="z-index: 1000;">
                                <input type="hidden" value="<?php echo e($product->id); ?>" id="productId">
                                <!-- Product Quantity -->
                                <div class="product_quantity clearfix">
                                    <span>Quantity: </span>
                                    <input id="quantity_input" name="quantity" type="text" pattern="[0-9]*" value="1">
                                    <div class="quantity_buttons">
                                        <div id="quantity_inc_button" class="quantity_inc quantity_control"><i class="fa fa-chevron-up"></i></div>
                                        <div id="quantity_dec_button" class="quantity_dec quantity_control"><i class="fa fa-chevron-down"></i></div>
                                    </div>
                                </div>
                                <br>
                                <!-- Product Size -->
                                <?php $__currentLoopData = $product->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul class="product_size">
                                    <li>
                                        <span><?php echo e($option->name); ?></span>
                                        <select name="variants" class="size_list variants" id="variants<?php echo e($option->name); ?>">
                                            <option value="" selected disabled>Select <?php echo e($option->name); ?></option>
                                            <?php $__currentLoopData = $option->optionValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->value); ?></option>    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                            
                                        </select>
                                    </li>
                                    
                                </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- Product Color -->
                               
                                

                            </div>

                            
                            <div class="button_container">
                                <a href="javascript:void(0);" class="btn btn-primary btn-sm" onclick="addToCart('<?php echo e($product->id); ?>')" >Add to Cart</a>
                                <a href="<?php echo e($product->affiliate_link); ?>" class="btn btn-info btn-sm" target="_blank"><i class="fa">&#xf270;</i> Buy From Amazon</a>
                                <div class="product_fav"><i class="fa fa-heart"></i></div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src='<?php echo e(asset('assets/js/jquery.ez-plus.js')); ?>'></script>
<script src="<?php echo e(asset('assets/js/product_custom.js')); ?>"></script>
<?php echo $__env->make('pantoneclo.ajax.addToCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pantoneclo.ajax.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/products.blade.php ENDPATH**/ ?>