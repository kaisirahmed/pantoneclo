<!-- Top Bar -->

<?php echo $__env->make('layouts.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Header Main -->

<?php echo $__env->make('layouts.partials.headermain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main Navigation -->

<?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>