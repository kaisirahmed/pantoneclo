<?php echo e($slot); ?>

<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>