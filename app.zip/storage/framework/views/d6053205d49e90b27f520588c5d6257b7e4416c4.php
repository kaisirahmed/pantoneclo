<!DOCTYPE html>
<html lang="en">
<head>
<title>Pantoneclo | <?php echo $__env->yieldContent('title'); ?></title>
<link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/images/icon.png')); ?>">
<?php echo $__env->make('layouts.partials.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('style'); ?>

</head>

<body>

<div class="super_container">
	
	<!-- Header -->
	
	<header class="header">

		<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</header>
	
	<!-- Banner -->

	<?php echo $__env->yieldContent('banner'); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<!-- Recently Viewed -->

	

	<!-- Brands -->

	

	<!-- Newsletter -->

	<?php echo $__env->make('layouts.partials.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Footer -->

	<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Copyright -->

	<?php echo $__env->make('layouts.partials.copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
</div>
<?php echo $__env->make('pantoneclo.ajax.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>
 
</body>

</html>

<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/app.blade.php ENDPATH**/ ?>