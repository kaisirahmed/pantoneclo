
<?php $__env->startSection('title','Variation Edit'); ?>
<?php $__env->startSection('content'); ?>
<?php echo Form::open([ 'method'=>'POST', 'route' => ['admin.variations.update',$product], 'files' => true]); ?>

<?php echo csrf_field(); ?>
<div class="container page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h5 class="m-0"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a> /<a href="<?php echo e(route('admin.products.index')); ?>"> Products</a> / Variations Edit</h5>
        <button type="submit" class="btn btn-success ml-1">Save<i class="material-icons">edit</i></button>
    </div>
</div>

<div class="container page__container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
              
                <div class="card-header card-header-tabs-basic nav" role="tablist">
                    <a href="<?php echo e(route('admin.products.edit',$product)); ?>">Product Info</a>
                    <a href="<?php echo e(route('admin.attributes.edit',$product)); ?>">Attributes</a>
                    <a href="#variation" class="active" data-toggle="tab" role="tab" aria-controls="variation" aria-selected="true">Variation</a>
                </div>
                <div class="card-body tab-content">
                    <div class="tab-pane active show fade" id="variation">
                        <div class="col-lg-12 card-form__body">
                            <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-category-name","js-lists-values-parent-name"]'>
                                <div class="search-form search-form--light m-3">
                                    <input type="text" class="form-control search" placeholder="Search">
                                    <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                                </div>
                                <table class="table mb-0 thead-border-top-0">
                                    <thead class="bg-black">
                                        <tr>
                                            <th>Default</th>
                                            <th></th>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>SKU</th>
                                            <th>Price</th>
                                            <th>Sale Price</th>
                                            <th>Quantity</th>
                                        </tr>
                                    </thead>
                                    <tbody class="list" id="staff">
                                        <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                        <tr>
                                                                                        
                                            <td>
                                                <div class="custom-control">
                                                    <input type="radio" name="is_default" value="<?php echo e($variation->id); ?>" <?php echo e($variation->is_default == 1 ? 'checked' : ''); ?>>
                                                    <input type="hidden" name="variant_id<?php echo e($variation->id); ?>" value="<?php echo e($variation->id); ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <?php if($variation->image != null): ?>
                                                <div class="avatar">
                                                    <img src="<?php echo e($variation->image); ?>" alt="Avatar" class="avatar-img">
                                                </div>
                                                <?php else: ?>
                                                <div class="avatar">
                                                    <img src="<?php echo e(asset('admin/assets/images/account-add-photo.png')); ?>" alt="Avatar" id="image<?php echo e($variation->id); ?>" class="avatar-img">
                                                </div>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <div class="col-12 col-md-12 mb-3">
                                                    <input type="text" name="image<?php echo e($variation->id); ?>" class="form-control" id="imageLink<?php echo e($variation->id); ?>" placeholder="image" value="<?php echo e($variation->image); ?>" required="" onkeyup="showImage(<?php echo e($variation->id); ?>)">
                                                </div>

                                            </td>
                                            <td>
                                                <input type="hidden" class="form-control" value="<?php echo e($variation->code); ?>">
                                                <span><?php echo e($variation->name); ?></span>
                                            </td>
                                            <td>
                                                <div class="col-12 col-md-12 mb-3">
                                                    <input type="text" name="sku<?php echo e($variation->id); ?>" class="form-control" id="sku" placeholder="SKU" value="<?php echo e($variation->sku); ?>" required="">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="col-12 col-md-12 mb-3">
                                                    <input type="number" name="price<?php echo e($variation->id); ?>" class="form-control" id="price" placeholder="Price" min="0" value="<?php echo e($variation->price); ?>" step="0.01" required="">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="col-12 col-md-12 mb-3">
                                                    <input type="number" name="sale_price<?php echo e($variation->id); ?>" class="form-control" id="sale_price" placeholder="Price" min="0" value="<?php echo e($variation->sale_price); ?>" step="0.01" required="">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="col-12 col-md-12 mb-3">
                                                    <input type="number" name="quantity<?php echo e($variation->id); ?>" class="form-control" id="quantity" placeholder="Quantity" min="0" value="<?php echo e($variation->quantity); ?>" required="">
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success ml-1">Save<i class="material-icons">edit</i></button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
    <!-- Range Slider -->
    <script src="<?php echo e(asset('admin/assets/vendor/ion.rangeSlider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/ion-rangeslider.js')); ?>"></script>

    <!-- jQuery Mask Plugin -->
    <script src="<?php echo e(asset('admin/assets/vendor/jquery.mask.min.js')); ?>"></script>

    <!-- Quill -->
    <script src="<?php echo e(asset('admin/assets/vendor/quill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/quill.js')); ?>"></script>

    <!-- Dropzone -->
    <script src="<?php echo e(asset('admin/assets/vendor/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/dropzone.js')); ?>"></script>

    <!-- Select2 -->
    <script src="<?php echo e(asset('admin/assets/vendor/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/select2.js')); ?>"></script>

    <script>
        function showImage(id){
            
            var imageLink = $('#imageLink'+id).val();
            if(imageLink != ''){
                $('#image'+id).attr('src',imageLink);
            } else {
                $('#image'+id).attr('src','<?php echo e(asset("admin/assets/images/account-add-photo.png")); ?>');
            }
            
            
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/variations/edit.blade.php ENDPATH**/ ?>