<nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
    <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h2 class="m-0 text-primary">Pantoneclo</h2>
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="<?php echo e(route('index')); ?>" class="nav-item nav-link active">Home</a>
            <a href="<?php echo e(route('service.b2b')); ?>" class="nav-item nav-link">Shop</a>
            <a href="about.html" class="nav-item nav-link">About</a>
            <a href="contact.html" class="nav-item nav-link">Contact</a>
            <a href="<?php echo e(route('login')); ?>" class="nav-item nav-link">Login</a>
            <a href="contact.html" class="nav-item nav-link"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
        </div>
    </div>
</nav><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>