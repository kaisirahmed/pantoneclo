
<?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li class="<?php echo e(count($subcategory->subcategory) > 0 ? 'hassubs' : ''); ?>">
        <a href="<?php echo e(route('category.products',$subcategory->slug)); ?>"><?php echo e($subcategory->name); ?><i class="fa fa-chevron-right ml-auto"></i></a>
        
        <?php if(count($subcategory->subcategory) > 0): ?>
        <ul>
            
                <?php echo $__env->make('layouts.partials.subcategories', ['subcategories' => $subcategory->subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </ul>
        
        <?php endif; ?>
    </li>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/subcategories.blade.php ENDPATH**/ ?>