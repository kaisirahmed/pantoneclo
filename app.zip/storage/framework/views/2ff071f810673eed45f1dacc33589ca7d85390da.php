<div class="container-fluid p-0 wow fadeIn" data-wow-delay="0.1s">

    <div class="owl-carousel-item position-relative" data-dot="<img src='<?php echo e(asset('assets/img/carousel-1.jpg')); ?>'>">
        <img class="img-fluid carousel-img" height="200px" src="<?php echo e(asset('assets/img/carousel-1.jpg')); ?>" alt="">
        <div class="owl-carousel-inner">
            <div class="container">
                
            </div>
        </div>
    </div>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/carousel.blade.php ENDPATH**/ ?>