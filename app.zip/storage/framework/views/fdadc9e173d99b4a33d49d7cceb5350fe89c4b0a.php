<!-- Main Nav Menu -->

<div class="main_nav_menu ml-auto">
    <ul class="standard_dropdown main_nav_dropdown">
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->parent_id == 0): ?> 
            <li class="<?php echo e(count($category->subcategory) > 0 ? 'hassubs' : ''); ?>">
                <a href="<?php echo e(route('category.products',$category->slug)); ?>"><?php echo e($category->name); ?></a>
                <?php if(count($category->subcategory) > 0): ?>
                <ul>
                    <?php echo $__env->make('layouts.partials.subcategories', ['subcategories' => $category->subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ul>
                <?php endif; ?>
            </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        
        <?php if(auth()->check()): ?>
        <li>
            <a href="<?php echo e(route('account')); ?>"><?php echo e(auth()->user()->name); ?></a>
        </li>
        <?php else: ?>
        <li>
            <a href="<?php echo e(route('login')); ?>">Login</a>
        </li>
        <li>
            <a href="<?php echo e(route('register')); ?>">Register</a>
        </li>
        <?php endif; ?>
        <!-- Cart -->
        <li>
            <div class="cart">
                <a href="<?php echo e(route('cart')); ?>">
                    <div class="cart_container d-flex flex-row align-items-center justify-content-end">
                        <div class="cart_icon">
                            <img src="<?php echo e(asset('assets/images/cart.png')); ?>" alt="">
                            <div class="cart_count"><span><?php echo e($cartTotalQuantity); ?></span></div>
                        </div>
                        
                        
                    </div>
                </a>
            </div>
        </li>
    </ul>
</div>  <?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/menu.blade.php ENDPATH**/ ?>