<!-- Main Nav Menu -->

<div class="main_nav_menu ml-auto">
    <ul class="standard_dropdown main_nav_dropdown">
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('category.products',$category->slug)); ?>"><?php echo e($category->name); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Cart -->
        <li>
            <div class="cart">
                <a href="<?php echo e(route('cart')); ?>">
                    <div class="cart_container d-flex flex-row align-items-center justify-content-end">
                        <div class="cart_icon">
                            <img src="<?php echo e(asset('assets/images/cart.png')); ?>" alt="">
                            <div class="cart_count"><span><?php echo e($cartTotalQuantity); ?></span></div>
                        </div>
                        
                        
                    </div>
                </a>
            </div>
        </li>
        <?php if(auth()->check()): ?>
        <li>
            <a href="<?php echo e(route('account')); ?>"><?php echo e(auth()->user()->name); ?></a>
        </li>
        <?php endif; ?>
    </ul>
</div>  <?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/menu.blade.php ENDPATH**/ ?>