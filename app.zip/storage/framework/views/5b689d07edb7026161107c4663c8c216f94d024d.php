
<?php $__env->startSection('title','Order Update'); ?>
<?php $__env->startSection('content'); ?>
<?php echo Form::open([ 'method'=>'PATCH', 'route' => ['admin.orders.update',$order->id], 'files' => true]); ?>

<?php echo csrf_field(); ?>
<div class="container-fluid page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h4 class="m-0"> <?php echo $__env->yieldContent('title'); ?> </h4>
        <button type="submit" class="btn btn-success btn-outline ml-1">Save<i class="material-icons">save</i></button>
    </div>
</div>

<div class="container page__container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="page__heading d-flex align-items-center justify-content-between">
                    <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="card-body tab-content">
                    <div class="tab-pane active show fade" id="generalinfo">
                    
                        <div class="card card-form">
                            <div class="row no-gutters">
                                <div class="col-lg-2 card-body">
                                    <p><strong class="headings-color">Order</strong></p>
                                </div>
                                <div class="col-lg-10 card-form__body card-body">
                                    <div class="was-validated">
                                        <div class="form-row">
                                            <div class="col-12 col-md-6 mb-3">
                                                <label for="name">Shipping Chanrge</label>
                                                <input type="text" name="shipping_charge" class="form-control" id="shipping_charge" placeholder="Shipping Charge" value="<?php echo e($order->shipping_charge); ?>" required="">
                                                <div class="invalid-feedback">Please provide a shipping charge.</div>
                                                <div class="valid-feedback">Looks good!</div>
                                            </div>
                                            <div class="col-12 col-md-6 mb-3">
                                                <label for="date">Shipping Date</label>
                                                <input id="date" type="hidden" name="shipping_date" class="form-control flatpickr-input" placeholder="" data-toggle="flatpickr" value="<?php echo e($order->shipping_date); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                                        
                        <div class="card card-form">
                            <div class="row no-gutters">
                                <div class="col-lg-2 card-body">
                                    <p><strong class="headings-color">Status</strong></p>
                                    <p class="text-muted">This is for save the order status</p>
                                </div>
                                <div class="col-lg-10 card-form__body card-body">
                                    <div class="form-row">
                                        <div class="col-12 col-md-6 mb-3">
                                            <div class="flex">
                                                <label for="Product Status">Order Status</label>
                                                <select id="status" name="status" data-toggle="select" class="form-control">
                                                    <?php $__currentLoopData = config('orders.getStatus'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>" <?php echo e($key == $order->status ? 'selected' : ''); ?>><?php echo e($status['label']); ?></option>    
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
 
                        <button type="submit" class="btn btn-success ml-1">Save<i class="material-icons">save</i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/orders/edit.blade.php ENDPATH**/ ?>