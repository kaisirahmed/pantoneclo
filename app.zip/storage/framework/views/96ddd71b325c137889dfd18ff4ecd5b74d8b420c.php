
<?php $__env->startSection('title', 'Products List'); ?>
<?php $__env->startSection('routes'); ?>
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h4 class="m-0">Products</h4>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-success ml-1">Create <i class="material-icons">add_box</i></a>
    </div>
</div>
<div class="container page__container">
    <div class="card card-form">
        <div class="row no-gutters">
            
            <div class="col-lg-12 card-form__body">

                <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-category-name","js-lists-values-parent-name"]'>
                    <div class="search-form search-form--light m-3">
                        <input type="text" class="form-control search" placeholder="Search">
                        <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                    </div>
                    <table class="table mb-0 thead-border-top-0">
                        <thead class="bg-black">
                            <tr>

                                <th style="width: 18px;">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#staff" id="customCheckAll">
                                        <label class="custom-control-label" for="customCheckAll"><span class="text-hide">Toggle all</span></label>
                                    </div>
                                    
                                </th>
                                <th>Image</th>
                                <th>
                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-product-name">Name</a>
                                </th>
                                <th>Variations</th>
                                <th>
                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-parent-name">Category</a>
                                </th>
                                
                                <th>Price</th> 
                                <th>Discount Amount</th> 
                                <th>Discount Percentage</th> 
                                <th>Sale Price</th> 
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="list" id="staff">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-check-selected-row" id="product-check" value="<?php echo e($product->id); ?>">
                                        <label class="custom-control-label" for="product-check"><span class="text-hide">Check</span></label>
                                    </div>
                                </td>
                                <td><img width="50px" src="<?php echo e($product->image); ?>" alt="<?php echo e($product->image); ?>"></td>
                                <td width="20%">
                                    <span class="js-lists-values-product-name"><?php echo e($product->name); ?></span>
                                </td>
                                <td style="background-color:floralwhite"><?php echo e($product->variants()->count()); ?></td>
                                <td>
                                    <span class="js-lists-values-parent-name">
                                        <?php echo e(implode(', ', $product->categories()->get()->sortBy('name')->pluck('name')->toArray())); ?>

                                    </span>
                                    
                                </td>
                                
                                <td><?php echo e(floatval($product->price)); ?> $</td>
                                <td><?php echo e(floatval($product->discount_amount)); ?></td>
                                <td><?php echo e(floatval($product->discount_percentage)); ?>&#37;</td>
                                <td><?php echo e(floatval($product->sale_price)); ?> $</td>
                                <td><span class="badge badge-<?php echo e($product->status === 1 ? 'success' : 'warning'); ?>"><?php echo e($product->status === 1 ? 'Active' : 'Draft'); ?></span></td>
                                
                                
                                <td>
                                    <div class="dropdown ml-auto">
                                        <a href="javascript:void(0)" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown" aria-expanded="false">
                                            <i class="material-icons">more_vert</i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right" style="display: none;">
                                            <a class="dropdown-item text-warning" href="<?php echo e(route('admin.products.edit', $product->id)); ?>"><i class="material-icons">edit</i> Edit</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item text-success" href="<?php echo e(route('admin.products.show', $product->id)); ?>"><i class="material-icons">view_list</i> View</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item text-danger" href="#" type="submit" onclick="confirmDelete('<?php echo e($product->id); ?>')"><i class="material-icons">delete</i> Delete</a>
                                            <form id="delete<?php echo e($product->id); ?>" action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo e(method_field('DELETE')); ?>

                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="card-body text-center">
                        <?php echo e($products->links()); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>

</div>
        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <!-- List.js -->
  <script src="<?php echo e(asset('admin/assets/vendor/list.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/list.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/products/index.blade.php ENDPATH**/ ?>