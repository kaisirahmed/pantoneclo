<form id="userUpdateForm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Email:</label>
        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
        value="<?php echo e($user->email); ?>"
        placeholder="Enter Email Address..."/>
        <p class="invalid-feedback" role="alert">
        </p>
    </div>
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Name:</label>
        <input type="text" class="form-control form-control-user <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e($user->name); ?>" placeholder="First Name">
        <p class="invalid-feedback" role="alert">
        </p>
    </div>
    
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Phone:</label>
        <input type="tel" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->phone); ?>" placeholder="Phone number">
        <p class="invalid-feedback" role="alert">
        </p>
    </div>
    <a href="javascript:void(0);" class="btn btn-primary float-right" onclick="updateUser()"><?php echo e(__('Update')); ?></a>
</form>
<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/account/useredit.blade.php ENDPATH**/ ?>