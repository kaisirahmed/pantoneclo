<div class="navbar navbar-expand-sm navbar-main navbar-dark bg-primary pl-md-0 pr-0" id="navbar" data-primary>
    <div class="container-fluid pr-0 ">

        <!-- Navbar toggler -->
        <button class="navbar-toggler navbar-toggler-custom d-lg-none d-flex mr-navbar" type="button" data-toggle="sidebar">
            <span class="material-icons">short_text</span>
        </button>


        <div class="d-flex sidebar-account flex-shrink-0 mr-auto mr-lg-0">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex d-flex align-items-center text-underline-0">
                
                <span class="flex d-flex flex-column text-white">
                    
                    <strong class="mr-1 sidebar-brand"><img width="10%" src="<?php echo e(asset('assets/images/icon.png')); ?>" alt="">PENTONECLO</strong>
                </span>
            </a>
        </div>


        



        


        

        <div class="dropdown">
            <a href="#account_menu" class="dropdown-toggle navbar-toggler navbar-toggler-dashboard border-left d-flex align-items-center ml-navbar" data-toggle="dropdown">
                
                <span class="ml-1 d-flex-inline">
                    <span class="text-light material-icons">verified_user</span><?php echo e(Auth::user()->name); ?>

                </span>
            </a>
            <div id="company_menu" class="dropdown-menu dropdown-menu-right navbar-company-menu">
                <div class="dropdown-item d-flex align-items-center py-2 navbar-company-info py-3">

                    <span class="mr-3">
                        <img src="<?php echo e(asset('assets/images/icon.png')); ?>" width="43" height="43" alt="avatar">
                    </span>
                    <span class="flex d-flex flex-column">
                        <strong class="h5 m-0"><?php echo e(auth()->user()->name); ?></strong>
                        <small class="text-muted text-uppercase">Admin</small>
                    </span>

                </div>
                <div class="dropdown-divider"></div>
                
                <a class="dropdown-item d-flex align-items-center py-2" href="<?php echo e(route('admin.logout')); ?>" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                    <span class="material-icons mr-2">exit_to_app</span> Logout
                     <form id="frm-logout" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                         <?php echo csrf_field(); ?>
                     </form>
                </a>
            </div>
        </div>

    </div>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/components/header/header.blade.php ENDPATH**/ ?>