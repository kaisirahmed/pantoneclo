
<?php $__env->startSection('title', 'Stock'); ?>
<?php $__env->startSection('content'); ?>
 
<div class="container-fluid page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h5 class="m-0"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a> / Stock</h5>
    </div>
</div>
<div class="container page__container">
    <div class="card card-form">
        <div class="row no-gutters">
            
            <div class="col-lg-12 card-form__body">


                <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-sku-name","js-lists-values-model-name"]'>
                    <div class="search-form search-form--light m-3">
                        <input type="text" class="form-control search" placeholder="Search">
                        <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                    </div>
                    <table class="table mb-0 thead-border-top-0">
                        <thead class="bg-black">
                            <tr>

                                <th style="width: 18px;">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#staff" id="customCheckAll">
                                        <label class="custom-control-label" for="customCheckAll"><span class="text-hide">Toggle all</span></label>
                                    </div>
                                    
                                </th>
                                <th>Image</th>
                                <th>
                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-sku-name">Sku</a>
                                </th>
                                <th>Variation</th>
                                
                                <th><a href="javascript:void(0)" class="sort" data-sort="js-lists-values-model-name">Model</a></th>
                                <th>Quantity</th>
                                <th>Status</th>
                                
                            </tr>
                        </thead>
                        <tbody class="list" id="staff">
                            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_1" value="<?php echo e($stock->id); ?>">
                                        <label class="custom-control-label" for="customCheck1_1"><span class="text-hide">Check</span></label>
                                    </div>
                                </td>

                                <td>
                                    <div class="avatar">
                                        <img src="<?php echo e($stock->image != null ? $stock->image : asset('admin/assets/images/account-add-photo.png')); ?>" alt="" class="avatar-img">
                                    </div>
                                </td>
                                <td><span class="js-lists-values-sku-name"><?php echo e($stock->sku); ?></span></td>
                                <td><?php echo e($stock->name); ?></td>
                                <td><span class="js-lists-values-model-name"><?php echo e($stock->model); ?></span></td>
                                <td><?php echo e($stock->quantity); ?></td>
                                <td><span class="badge badge-<?php echo e($stock->status === 1 ? 'success' : 'warning'); ?>"><?php echo e($stock->status === 1 ? 'Active' : 'Draft'); ?></span></td>
                                
                                
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>

</div>
        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <!-- List.js -->
  <script src="<?php echo e(asset('admin/assets/vendor/list.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/list.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/stocks/index.blade.php ENDPATH**/ ?>