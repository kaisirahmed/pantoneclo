
<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('content'); ?>
 
<div class="container-fluid page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h5 class="m-0"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a> / <a href="<?php echo e(route('admin.orders.index')); ?>">Orders</a> / Order View</h5>
    </div>
</div>
<div class="container-fluid page__container">
    <div class="alert alert-soft-warning d-flex align-items-center card-margin" role="alert">
        <i class="material-icons mr-3">error_outline</i>
        <div class="text-body">
            You have an order ID <a href="#">#<?php echo e($order->order_number); ?></a> due for
            <strong class="text-danger">$ <?php echo e($order->total); ?></strong>
        </div>
        
    </div>

    <div class="card card-form">
        <div class="row no-gutters">
            <div class="col-lg-4 card-body">
                <p><strong class="headings-color"><?php echo e($order->user->name); ?></strong></p>
                <p>Payment Method: <?php echo e($order->payment_method); ?></p>
                <p>Order Date: <?php echo e(date("Y-m-d",strtotime($order->date))); ?></p>
                <p>Shipping Date: <?php echo e(date("Y-m-d",strtotime($order->shipping_date))); ?></p>
                <p>Status: <span class="badge badge-<?php echo e(config('orders.getStatus.'.$order->status.'.color')); ?>"><?php echo e(config('orders.getStatus.'.$order->status.'.label')); ?></span></p>
            </div>
            <div class="col-lg-4 card-form__body card-body">

                <div class="d-flex align-items-center flex-wrap">
                    <div class="mr-3">
                        <strong>Billing Address</strong>
                        <p><?php echo e($order->billing()->first_name." ".$order->billing()->last_name); ?><br>  
                        Phone: <?php echo e($order->billing()->phone); ?> <br>Email: <?php echo e($order->billing()->email); ?> <br>
                        Location: <?php echo e($order->billing()->street); ?>, <?php echo e($order->billing()->street2); ?>, <?php echo e(($order->billing()->city != 0 ? $order->billing()->city->name : '')); ?>, <?php echo e($order->billing()->state->name); ?>, <?php echo e($order->billing()->country->name); ?> <br> 
                        Zip Code: <?php echo e($order->billing()->zip); ?>

                        </p>
                    </div>                   
                </div>

            </div>
            <div class="col-lg-4 card-form__body card-body">

                <div class="d-flex align-items-center flex-wrap">
                    <div class="mr-3">
                        <strong>Shipping Address</strong>
                        <p><?php echo e($order->shipping()->first_name." ".$order->shipping()->last_name); ?><br>  
                        Phone: <?php echo e($order->shipping()->phone); ?> <br>Email: <?php echo e($order->shipping()->email); ?> <br>
                        Location: <?php echo e($order->shipping()->street); ?>, <?php echo e($order->shipping()->street2); ?>, <?php echo e(($order->shipping()->city != 0 ? $order->shipping()->city->name : '')); ?>, <?php echo e($order->shipping()->state->name); ?>, <?php echo e($order->shipping()->country->name); ?> <br> 
                        Zip Code: <?php echo e($order->shipping()->zip); ?>

                        </p>
                    </div>

                     
                </div>

            </div>

        </div>
    </div>



    <div class="card card-form">
        <div class="row no-gutters">
            <div class="col-lg-2 card-body">
                <p><strong class="headings-color">Invoices</strong></p>
                <p class="text-muted mb-0"><?php echo e($order->invoice_number); ?></p>
            </div>
            <div class="col-lg-10 card-form__body">

                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th class="text-center">Price</th>
                                <th class="text-center">Variation</th>
                                <th class="text-center">Quantity</th>
                                <th class="text-center">Discount</th>
                                <th class="text-center">Amount</th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                            <tr>
                                <td width="20%"><?php echo e($item->product->name); ?></td>
                                <td class="text-center"><?php echo e($item->product_price); ?>$</td>
                                <td class="text-center"><?php echo e($item->variation); ?></td>
                                <td class="text-center"><?php echo e($item->quantity); ?></td>
                                <td class="text-center"><?php echo e($item->discount_amount); ?></td>
                                <td class="text-center"><?php echo e($item->total_price); ?>$</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

</div>
        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <!-- List.js -->
  <script src="<?php echo e(asset('admin/assets/vendor/list.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/list.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>