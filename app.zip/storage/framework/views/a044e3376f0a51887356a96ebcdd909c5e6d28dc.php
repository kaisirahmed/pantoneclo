<aside class="col-md-3">
    <nav class="list-group">
        <a class="list-group-item active" href="<?php echo e(route('account')); ?>"> Account overview  </a>
        
        <a class="list-group-item" href="<?php echo e(route('account.orders')); ?>"> My Orders </a>
        
        
        <a class="list-group-item" href="page-profile-setting.html"> Settings </a>
        <a class="list-group-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('sidebar-logout').submit();"> Log out </a>
        <form id="sidebar-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </nav>
</aside> <!-- col.// --><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/account/sidebar.blade.php ENDPATH**/ ?>