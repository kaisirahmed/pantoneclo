
<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('content'); ?>
 
<div class="container-fluid page__heading-container">
    <div class="page__heading d-flex align-items-center justify-content-between">
        <h5 class="m-0"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a> / Orders</h5>
    </div>
</div>
<div class="container page__container">
    <div class="card card-form">
        <div class="row no-gutters">
            
            <div class="col-lg-12 card-form__body">


                <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-order-date-name","js-lists-values-order-id-name","js-lists-values-customer-name"]'>
                    <div class="search-form search-form--light m-3">
                        <input type="text" class="form-control search" placeholder="Search">
                        <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                    </div>
                    <table class="table mb-0 thead-border-top-0">
                        <thead class="bg-black">
                            <tr>

                                <th style="width: 18px;">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#staff" id="customCheckAll">
                                        <label class="custom-control-label" for="customCheckAll"><span class="text-hide">Toggle all</span></label>
                                    </div>
                                    
                                </th>
                                <th>
                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-order-id-name">Order ID</a>
                                </th>
                                <th><a href="javascript:void(0)" class="sort" data-sort="js-lists-values-order-date-name">Order Date</th>
                                
                                <th><a href="javascript:void(0)" class="sort" data-sort="js-lists-values-customer-name">Customer</a></th>
                                <th>Quantity</th>
                                <th>Shipping Charge</th>
                                <th>Total</th>
                                <th>Shipping Date</th>  
                                <th>Payment Method</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="list" id="staff">
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_1" value="<?php echo e($order->id); ?>">
                                        <label class="custom-control-label" for="customCheck1_1"><span class="text-hide">Check</span></label>
                                    </div>
                                </td>

                                <td><span class="js-lists-values-order-id-name"><?php echo e($order->order_number); ?></span></td>
                                <td><span class="js-lists-values-order-date-name"><?php echo e(date("Y-m-d",strtotime($order->date))); ?></span></td>
                                <td><span class="js-lists-values-customer-name"><?php echo e($order->user->name); ?></span></td>
                                <td><?php echo e($order->quantity); ?></td>
                                <td><?php echo e($order->shipping_charge); ?></td>
                                <td><?php echo e($order->total); ?></td>
                                <td><?php echo e(date("Y-m-d",strtotime($order->shipping_date))); ?></td>
                                <td><?php echo e($order->payment_method); ?></td>
                                <td><span class="badge badge-<?php echo e(config('orders.getStatus.'.$order->status.'.color')); ?>"><?php echo e(config('orders.getStatus.'.$order->status.'.label')); ?></span></td>
                                <td>
                                    <div class="dropdown ml-auto">
                                        <a href="javascript:void(0)" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown" aria-expanded="false">
                                            <i class="material-icons">more_vert</i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right" style="display: none;">
                                            
                                            <a class="dropdown-item text-success" href="<?php echo e(route('admin.orders.show', $order->id)); ?>"><i class="material-icons">view_list</i> View</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item text-danger" href="#" type="submit" onclick="confirmDelete('<?php echo e($order->id); ?>')"><i class="material-icons">delete</i> Delete</a>
                                            <form id="delete<?php echo e($order->id); ?>" action="<?php echo e(route('admin.orders.destroy', $order->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo e(method_field('DELETE')); ?>

                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>

</div>
        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <!-- List.js -->
  <script src="<?php echo e(asset('admin/assets/vendor/list.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/list.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>