
<div class="home">
    
    <div class="home_overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="home_content d-flex flex-column">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                          <li class="breadcrumb-item active" aria-current="page"><?php echo $__env->yieldContent('title'); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
        
<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/pagebanner.blade.php ENDPATH**/ ?>