<?php $__env->startComponent('mail::message'); ?>
# Introduction

Welcome to Pantoneclo

You have created an account and credentials are given below:

your username: <?php echo e($user['email']); ?>

password: <?php echo e($user['password']); ?>


<?php $__env->startComponent('mail::button', ['url' => '/login']); ?>
Click to Login
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/emails/register.blade.php ENDPATH**/ ?>