<footer class="footer">
    <div class="container">
        <div class="row">

            <div class="col-lg-3 footer_col">
                <div class="footer_column footer_contact">
                    <div class="logo_container">
                        <div class="logo"><a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/images/pantoneclo.png')); ?>" width="200px" height="60px"></a></div>
                    </div>
                    <div class="footer_title">Got Question? Call Us 24/7</div>
                    <div class="footer_phone"><a href="callto:+386 30 796 092">+386 30 796 092</a></div>
                    <div class="footer_contact_text">
                        <p>Pokopališka cesta 43000 </p>
                        <p>CeljeSlovenia</p>
                    </div>
                    <div class="footer_social">
                        <ul>
                            <li><a href="https://www.facebook.com/PantonecloEU/" target="_blank"><i class="fa fa-facebook-f"></i></a></li>
                            <li><a href="https://www.instagram.com/pantone_clo/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.youtube.com/channel/UCWGlFHHU_fvv01lO9IrTn5g" target="_blank"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="https://www.google.com.bd/search?q=Pantonclo&ludocid=12548668273068374647&lsig=AB86z5WTJsQ9lHO_2xwxm4jwjGvq" target="_blank"><i class="fa fa-google"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-2 offset-lg-2">
                <div class="footer_column">
                    <div class="footer_title">Find it Fast</div>
                    <ul class="footer_list">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('shop')); ?>">Shop</a></li>
                        <li><a href="<?php echo e(route('cart')); ?>">Cart</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                        <?php if(!auth()->check()): ?>
                        <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <div class="col-lg-2">
                <div class="footer_column">
                    <div class="footer_title">Policy</div>
                    <ul class="footer_list">
                        <li><a href="<?php echo e(route('privacy.policy')); ?>">Privacy Policy</a></li>
                        <li><a href="#">FAQs</a></li>
                        
                    </ul>
                </div>
            </div>
            <?php if(auth()->check()): ?>
            <div class="col-lg-2">
                <div class="footer_column">
                    <div class="footer_title">My Account</div>
                    <ul class="footer_list">
                        <li><a href="<?php echo e(route('account')); ?>">Account</a></li>
                        <li><a href="<?php echo e(route('account.orders')); ?>">My Orders</a></li>
                        
                    </ul>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</footer><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>