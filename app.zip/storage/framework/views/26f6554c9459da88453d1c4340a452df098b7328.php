
<?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($subcategory->id); ?>" <?php echo e($subcategory->id == $category->parent->id ? 'selected' : ''); ?>> &nbsp;&nbsp;&nbsp;&nbsp;
        <?php if(!count($subcategory->subcategory)): ?>
        &nbsp;&nbsp;&nbsp;&nbsp; 
        <?php endif; ?>
        <?php echo e($subcategory->name); ?>

    </option> 
    <?php if(count($subcategory->subcategory)): ?>
        <?php echo $__env->make('admin.category.subcategories', ['subcategories' => $subcategory->subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/category/subcategories.blade.php ENDPATH**/ ?>