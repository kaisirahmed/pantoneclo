<!-- jQuery -->
<script src="{{ asset('admin/assets/vendor/jquery.min.js') }}"></script>

<!-- Bootstrap -->
<script src="{{ asset('admin/assets/vendor/popper.min.js') }}"></script>
<script src="{{ asset('admin/assets/vendor/bootstrap.min.js') }}"></script>

<!-- Perfect Scrollbar -->
<script src="{{ asset('admin/assets/vendor/perfect-scrollbar.min.js') }}"></script>

<!-- DOM Factory -->
<script src="{{ asset('admin/assets/vendor/dom-factory.js') }}"></script>

<!-- MDK -->
<script src="{{ asset('admin/assets/vendor/material-design-kit.js') }}"></script>

<!-- Range Slider -->
<script src="{{ asset('admin/assets/vendor/ion.rangeSlider.min.js') }}"></script>
<script src="{{ asset('admin/assets/js/ion-rangeslider.js') }}"></script>

<!-- App -->
<script src="{{ asset('admin/assets/js/toggle-check-all.js') }}"></script>
<script src="{{ asset('admin/assets/js/check-selected-row.js') }}"></script>
<script src="{{ asset('admin/assets/js/dropdown.js') }}"></script>
<script src="{{ asset('admin/assets/js/sidebar-mini.js') }}"></script>
<script src="{{ asset('admin/assets/js/app.js') }}"></script>

<!-- App Settings (safe to remove) -->
<script src="{{ asset('admin/assets/js/app-settings.js') }}"></script>