<!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 # Introduction
<h4>{{ $data['name'] }}</h4>
<h4>{{ $data['email'] }}</h4>
<h4>{{ $data['subject'] }}</h4>
<h4>{{ $data['message'] }}</h4>
#The body of your message.
 
Thanks,<br>
{{ __($data['name']) }}
 </body>
 </html> 


