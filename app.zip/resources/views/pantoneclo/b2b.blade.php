@extends('layouts.app')
@section('title','Pentoneclo')
@section('content')
 <!-- Page Header Start -->
 @include('layouts.partials.pageheader')

<nav aria-label="breadcrumb animated slideInDown container">
    <ol class="breadcrumb justify-content-center">
        <li class="breadcrumb-item"><a href="{{ route('service.b2b') }}"
                class="btn btn-primary py-3 px-5 animated slideInLeft display-4">All
                Collection</a></li>
        <li class="breadcrumb-item"><a href="b2b_men_collection.html"
                class="btn btn-primary py-3 px-5 animated slideInLeft display-4">Men's
                Collection</a></li>
        <li class="breadcrumb-item"><a href="" class="btn btn-primary  py-3 px-5 animated slideInLeft">Women
                Collection</a></li>
        <li class="breadcrumb-item"><a href="" class="btn btn-primary  py-3 px-5 animated slideInLeft">Kid's
                Collection</a></li>

    </ol>
</nav>
<!-- Page Header End -->


<!-- Service Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
            <!-- <h6 class="display-2 text-primary">Our Services</h6> -->
            <!-- <h1 class="mb-4">We Are Pioneers In The World Of Renewable Energy</h1> -->
        </div>
        <div class="row g-4">
            @foreach($products as $product)
            <div class="col-md-6 col-lg-3 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item rounded overflow-hidden p-2">
                    <img class="card-img-top img-fluid " src="{{ $product->image }}" alt="">
                    <div class="position-relative p-4 pt-0">
                        <h4 class="mb-3 pt-3">{{ $product->name }}</h4>
                        <p>{{ mb_strimwidth($product->description,0,30,"...") }}</p>
                        <p style="color: red;">&#36;{{ $product->sale_price }}</p>
                        <a class="small fw-medium" href="{{ route('product.show',$product->slug) }}">Details<i
                                class="fa fa-arrow-right ms-2"></i></a>
                    </div>
                </div>
            </div>
            @endforeach
            
        </div>
    </div>
</div>
<!-- Service End -->
@endsection