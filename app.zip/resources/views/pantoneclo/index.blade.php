@extends('layouts.app')
@section('title','Pentoneclo')
@section('content')
<!-- Carousel Start -->
@include('layouts.partials.carousel')
<!-- Carousel End -->

<!-- About Start -->
{{-- @include('layouts.partials.about') --}}
<!-- About End -->

<!-- Testimonial Start -->
@include('layouts.partials.testimonial')
<!-- Testimonial End -->
@endsection