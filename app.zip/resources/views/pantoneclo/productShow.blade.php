@extends('layouts.app')
@section('title','Product Details')
@section('content')
@include('layouts.partials.pageheader')
    <!-- Feature Start -->
    <div class="container bg-light overflow-hidden my-5 px-lg-0 shadow-lg">
        <div class="container feature px-lg-0">
            <div class="row g-0 mx-lg-0">
                <div class="col-lg-6 pe-lg-0 wow fadeIn" data-wow-delay="0.5s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        {{-- <img width="50%" class="position-absolute img-fluid w-100" id="productImage" src="{{ $product->image }}"
                             alt=""> --}}
                        <div class="wp">
                            <aside class="h-100">
                                <div class="zoom">
                                    <div class="original">
                                        <img src="{{ $product->image }}" id="target">
                                    </div>
                                    <div class="viewer">
                                        <img src="{{ $product->image }}">
                                    </div>
                                    {{-- <div class="mgt">
                                        <input type="range" class="" min="2" max="10" value="2">
                                    </div> --}}
                                    <div class="magnifier"></div>
                                </div>	
                            </aside>
                                
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 py-5 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
                    <div class="p-lg-5 ps-lg-0">
                        <h3 class="mb-4">
                           {{ $product->name }}
                        </h3>
                        <p class="" style="color: red;">
                            <b>&#36;{{ $product->sale_price }}</b>
                        </p>
                        <p class="">
                            &#36;{{ $product->price }} ({{ $product->discount_percentage }}&#37; off)
                        </p>
                        <div class="row g-4">
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <div class="ms-1" style="color:#000;font-weight:400;">
                                        Stock: <span class="badge badge-success">Availabe</span>
                                    </div>
                                </div>
                            </div>
                            {{-- <div class="col-6">
                                <div class="d-flex align-items-center">

                                    <div class="ms-1">
                                        <h5 class="mb-0">Availabe</h5>
                                    </div>
                                </div>
                            </div> --}}
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <div class="ms-1">
                                        <h5 class="mb-0">Color Value</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <div class="ms-1">
                                        <h5 class="mb-0">Size Value</h5>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="container">
                            <div class="row">
                                <div class="col">
                                    <a class="btn btn-primary my-5 mx-auto" href="#">Buy Here</a>
                                </div>
                                <div class="col">
                                    <a class="btn btn-secondary my-5 mx-auto text-blue" href="{{ $product->affiliate_link }}" target="_blank"><i class="fab fa-amazon fa-fw"></i>Buy Amazon</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <p class="text-black">
                        {{ $product->description }}
                    </p>
                </div>

            </div>
        </div>
    </div>
    <!-- Feature End -->
 

@endsection

@section('script')
<script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"></script>
	<script type="text/javascript" src="{{ asset('assets/js/zoom.js') }}"></script>
	<script type="text/javascript">
		var l = $('#target').zoom(2);

		//$('input[type="range"]').on('change', function () {

			l.setZoom(this.value);

		//});
	</script>
@endsection