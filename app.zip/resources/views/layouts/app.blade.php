<!DOCTYPE html>
<html lang="en">

<head>
    @include('layouts.partials.meta')
    <!-- Libraries Stylesheet -->
    @include('layouts.partials.style')
    @yield('style')
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    @include('layouts.partials.topbar')
    <!-- Topbar End -->


    <!-- Navbar Start -->
    @include('layouts.partials.navbar')
    <!-- Navbar End -->


    @yield('content')


    <!-- Footer Start -->
    @include('layouts.partials.footer')
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i
            class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    @include('layouts.partials.script')
    @yield('script')
</body>

</html>