
@include('layouts.partials.slider')