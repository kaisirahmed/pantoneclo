<?php

namespace App\Http\Controllers\Admin;

use App\Models\Product;
use App\Models\Category;
use App\Models\Unit;
use App\Models\Size;
use App\Models\Color;
use App\Models\Option;
use App\Models\OptionValue;
use App\Models\Variation;
use Illuminate\Support\Str;
use App\Http\Controllers\Controller;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::where('status',1)->latest()->simplepaginate(20);
        $categoryId = Category::pluck('parent_id');
        $categories = Category::whereNotIn('id',$categoryId)->get();
        return view('admin.products.index',compact('products','categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $units = Unit::all();
        $categoryId = Category::pluck('parent_id');
        $categories = Category::whereNotIn('id',$categoryId)->get();
  
        return view('admin.products.create',compact('categories','units'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function imageUpload(Request $request){
        return $request->all();
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function variationProduct(Request $request){
        return $request->all();
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Product $product)
    {  //dd($request->all());
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string','max:100','unique:products,name'],
            'code' => ['nullable','string','max:30'],
            'affiliate_link' => ['nullable','string'],
            'model' => ['nullable','string'],
            'price' => ['required',],
            'image' => ['required','string'],//,'dimensions:min_width=200,max_width=250,min_height=250,max_height=250'
            'front_side_image' => ['required','string'],//,'dimensions:min_width=200,max_width=250,min_height=250,max_height=250'
            'right_side_image' => ['required','string'],//,'dimensions:min_width=200,max_width=250,min_height=250,max_height=250'
            'left_side_image' => ['required','string'],//,'dimensions:min_width=200,max_width=250,min_height=250,max_height=250'
            'back_side_image' => ['required','string'],//,'dimensions:min_width=200,max_width=250,min_height=250,max_height=250'
            'unit_id' => ['required','integer'],
            'status' => ['required','integer'],
            'description' => ['required','string'],
            'discount_amount' => ['nullable','integer'],
            'discount_percentage' => ['nullable','integer'],           
        ]);

        if ($validator->fails()) {
            return $validator->validate()->withInput();
        } else {
            $product->name = $request->name;
            $product->code = $request->code;
            $product->model = $request->model;
            $product->slug = Str::slug($request->name."-".$request->model."-".$product->code);
            $product->affiliate_link = $request->affiliate_link;
            $product->price = $request->price;
            
            $product->image = $request->image;
            $product->left_side_image = $request->left_side_image;
            $product->back_side_image = $request->back_side_image;
            $product->front_side_image = $request->front_side_image;
            $product->right_side_image = $request->right_side_image;
            
           
            $product->quantity = $request->quantity;
            $product->unit_id = $request->unit_id;
            $product->status = $request->status;
            $product->description = $request->description;
                
            if(isset($request->discount_amount) && $request->discount_amount > 0) {
                $discountAmount = $product->discount_amount = $request->discount_amount;
                $salePrice = $request->price - $discountAmount;
                $product->sale_price = $salePrice;
            }elseif(isset($request->discount_percentage) && $request->discount_percentage > 0) {
                $discountPercent = $product->discount_percentage = $request->discount_percentage;
                $discountAmount = $product->price * ($discountPercent / 100);
                $salePrice = $request->price - $discountAmount;
                $product->sale_price = $salePrice;
            }else {
                $product->sale_price = $request->sale_price;
            }
            
            // if(isset($request->special_image) && $request->special_offer == "on") {
            //     if ($request->has('special_image')) {
            //         $product->special_offer = $request->special_offer;
            //         $special_image = $request->file( 'special_image' );  
            //         $special_imageType = $special_image->getClientOriginalExtension();
            //         $special_imageStr = (string) Image::make( $special_image )->
            //                                 resize( 350, 350, function ( $constraint ) {
            //                                     $constraint->aspectRatio();
            //                                 })->encode( $special_imageType );
    
            //         $product->special_image = base64_encode( $special_imageStr );
            //         $product->special_image_type = $special_imageType;
            //     }
            // } else {
            //     $product->special_offer = null;
            //     $product->special_image = null;
            //     $product->special_image_type = null;
            // }

            // $product->meta_title = $request->meta_title;
            // $product->meta_tags = empty($request->hidden_meta_tags) ? null : json_encode(explode(",",$request->hidden_meta_tags));
            // $product->meta_description = $request->meta_description;

            if($product->save()) {
                $product->categories()->attach($request->category_id);
               
                $options = $request->options;                
                 
                $attributes = [];
                        
                foreach($options as $key => $name){
                    $attributes[$key] = $request->$key;            
                }

                foreach($attributes as $key => $attributeValues){
                    if(!Option::where('product_id',$product->id)->where('name',$key)->exists()){
                        $input['product_id'] = $product->id;
                        $input['name'] = ucfirst($key);
                        $option = Option::create($input);
                    }
                    
                    foreach($attributeValues as $value){
                        if($value != null && !OptionValue::where('option_id',$option->id)->where('value',$value)->exists()){
                            $inputvalue['option_id'] = $option->id;
                            $inputvalue['value'] = $value;
                            OptionValue::create($inputvalue);
                        }
                       
                    }
                }            
                
                Product::where('id',$product->id)->update(['has_option' => 1]);

                $productOptionSize = Option::where('product_id',$product->id)->where('name',$options['size'])->first();
                $productOptionColor = Option::where('product_id',$product->id)->where('name',$options['color'])->first();

                $optionValueSizes = OptionValue::where('option_id',$productOptionSize->id)->pluck('id')->toArray();
                $optionValueColors = OptionValue::where('option_id',$productOptionColor->id)->pluck('id')->toArray();
 
                $codeCombinationArray = [
                    'product' => [$product->id],
                    'size' => $optionValueSizes,
                    'color' => $optionValueColors,
                ];

                // Creating code for each variation
                $codeCombinations = $this->variations($codeCombinationArray);         
                $codes = [];

                foreach($codeCombinations as $code){
                    $codes[] = $code['product'].$code['size'].$code['color'];
                }
                //product variations by size and color
                $variationArray = [ 
                    'size' => $request->size,
                    'color' => $request->color,
                    'price' => [$product->price],
                ];
                
                
                $productVariations = $this->variations($variationArray);

                //Code merge with product variations
                $variations = [];
                foreach($productVariations as $vkey => $variation){
                    foreach($codes as $ckey => $code){
                        if($vkey == $ckey){
                            $variations[] = [
                                'size' => $variation['size'],
                                'color' => $variation['color'],
                                'price' => $variation['price'],
                                'code' => $code
                            ];
                        }
                    }
                }

                
                foreach($variations as $key => $variation){
                    $inputVariation['product_id'] = $product->id;
                    $inputVariation['sku'] = '';
                    $inputVariation['code'] = $variation['code'];
                    $inputVariation['name'] = $variation['size'].'/'.$variation['color'];
                    $inputVariation['price'] = $variation['price'];
                    $inputVariation['discount_amount'] = 0;
                    $inputVariation['discount_percentage'] = 0;
                    $inputVariation['sale_price'] = $product->sale_price;
                    $inputVariation['quantity'] = 0;
                    $inputVariation['is_default'] = $key == 0 ? 1 : 0;
                    Variation::create($inputVariation);
                }



                Session::flash('message','Product has been saved successfully.');
            } else {
                Session::flash('warning','Something is wrong when saving product.');
            }
            return redirect()->route('admin.variations.edit',$product->id);
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    function storeAttribute(Request $request, $id)
    {
        $arr = [
            'size'  => ['XS', 'S', 'M'],
            'color' => ['yellow', 'brown', 'white'],
            'weight'=> [
                'light' => [
                    'super',
                    'medium'
                ],
                'normal',
                'heavy' => [
                    'regular',
                    'most', 
                    'overload'
                ]
            ]
        ];

        
    }

    public function traverse($array, $parent_ind) {
        $r = [];
        $pr = '';

        if(!is_numeric($parent_ind)) {
            $pr = $parent_ind.'-';
        }

        foreach ($array as $ind => $el) {
            if (is_array($el)) {
                $r = array_merge($r, $this->traverse($el, $pr.(is_numeric($ind) ? '' : $ind)));
            } elseif (is_numeric($ind)) {
                $r[] = $pr.$el;
            } else {
                $r[] = $pr.$ind.'-'.$el;
            }
        }

        return $r;
    }

    public function variations($array) {
        if (empty($array)) {
            return [];
        }
    
        //1. Go through entire array and transform elements that are arrays into elements, collect keys
        $keys = [];
        $size = 1;
    
        foreach ($array as $key => $elems) {
            if (is_array($elems)) {
                $rr = [];
    
                foreach ($elems as $ind => $elem) {
                    if (is_array($elem)) {
                        $rr = array_merge($rr, $this->traverse($elem, $ind));
                    } else {
                        $rr[] = $elem;
                    }
                }
    
                $array[$key] = $rr;
                $size *= count($rr);
            }
    
            $keys[] = $key;
        }
    
        //2. Go through all new elems and make variations
        $rez = [];
        for ($i = 0; $i < $size; $i++) {
            $rez[$i] = [];
    
            foreach ($array as $key => $value) {
                $current = current($array[$key]);
                $rez[$i][$key] = $current;
            }
    
            foreach ($keys as $key) {
                if (!next($array[$key])) {
                    reset($array[$key]);
                } else {
                    break;
                }
            }
        }
    
        return $rez;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return view('product.show',compact('product'));
    }
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function variationsEdit($product){
        $variations = Variation::where('product_id',$product)->get();
        return view('admin.variations.edit',compact('variations','product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function variationsUpdate(Request $request, $product){
        //dd($request->all());
        $variationIds = Variation::where('product_id',$product)->pluck('id')->toArray();
        
        $variations = [];
        $count = 0;
        foreach($variationIds as $variationId){
            $variant_id = 'variant_id'.$variationId;
            $image = 'image'.$variationId;
            $sku = 'sku'.$variationId;
            $price = 'price'.$variationId;
            $sale_price = 'sale_price'.$variationId;
            $quantity = 'quantity'.$variationId;
            $is_default = $request->is_default == $variationId ? 1 : 0;
             
            $variations[$variationId]['variation_id'] = $request->$variant_id;
            $variations[$variationId]['image'] = $request->$image;
            $variations[$variationId]['sku'] = $request->$sku;
            $variations[$variationId]['price'] = $request->$price;
            $variations[$variationId]['sale_price'] = $request->$sale_price;
            $variations[$variationId]['quantity'] = $request->$quantity;
            $variations[$variationId]['is_default'] = $is_default;
        }
        //dd($variations);
        foreach($variations as $variation){
            $inputVariation['id'] = $variation['variation_id'];
            $inputVariation['image'] = $variation['image'];
            $inputVariation['sku'] = $variation['sku'];
            $inputVariation['price'] = $variation['price'];
            $inputVariation['sale_price'] = $variation['sale_price'];
            $inputVariation['quantity'] = $variation['quantity'];
            Variation::where('product_id',$product)->where('id',$inputVariation['id'])->update($inputVariation);
            $count++;
        }
        if(count($variations) == $count){
            Session::flash('message','Variation has been saved successfully.');
        } else {
            Session::flash('warning','Something is wrong when saving product.');
        }
        return redirect()->route('admin.products.index');

    }

    public function checkString($search,$value){
        if(preg_match("/{$search}/i", $value)) {
            return true;
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $units = Unit::all();
        $categoryId = Category::pluck('parent_id');
        $categories = Category::whereNotIn('id',$categoryId)->get();
        $product = Product::findOrFail($id);
        $optionSize = Option::where('product_id',$id)->where('name','size')->first();
        $optionColor = Option::where('product_id',$id)->where('name','color')->first();
        $variations = Variation::where('product_id',$id)->get();
        return view('admin.products.edit',compact('product','categories','units','optionSize','optionColor','variations'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string','max:100'],
            'name_bn' => ['required','string','max:100'],
            'sub_name' => ['nullable','string','max:100'],
            'sub_name_bn' => ['nullable','string','max:100'],
            'price' => ['required',],
            'image' => ['nullable','image', 'max:512','dimensions:min_width=200,max_width=250,min_height=250,max_height=250'],
            'quantity' => ['required','numeric','min:1'],
            'unit_id' => ['required','integer'],
            'status' => ['required','integer'],
            'discount' => ['nullable','string'],
            'description' => ['required','string'],
            'discount_amount' => ['nullable','integer'],
            'discount_percentage' => ['nullable','integer'],
            'special_offer' => ['nullable','string'],
            'special_image' => ['nullable','image', 'max:512','dimensions:min_width=350,max_width=400,min_height=350,max_height=400'],
        ],
        [
            'hidden_meta_tags.string' => 'Meta tags must be string.'
        ]);

        if ($validator->fails()) {
            return $validator->validate()->withInput();
        } else {
            $product->name = $request->name;
            $product->name_bn = $request->name_bn;
            $product->sub_name = $request->sub_name;
            $product->sub_name_bn = $request->sub_name_bn;
            $product->slug = Str::slug($request->name." ".$request->sub_name);
            $product->slug_bn = Str::slug($request->name_bn." ".$request->sub_name_bn);
            $product->price = $request->price;
            
            if ($request->has('image')) {

                $image = $request->file( 'image' );  
                $imageType = $image->getClientOriginalExtension();
                $imageStr = (string) Image::make( $image )->
                                        resize( 250, 250, function ( $constraint ) {
                                            $constraint->aspectRatio();
                                        })->encode( $imageType );

                $product->image = base64_encode( $imageStr );
                $product->image_type = $imageType;
            } else {
                $product->image = $product->image;
            }
            $product->quantity = $request->quantity;
            $product->unit_id = $request->unit_id;
            $product->status = $request->status;
            $product->description = $request->description;
            if($request->discount == "on") {
                
                if(isset($request->discount_amount)) {
                    $discountAmount = $product->discount_amount = $request->discount_amount;
                    $product->discount_percentage = null;
                    $salePrice = $request->price - $discountAmount;
                    $product->sale_price = $salePrice;
                }
                if(isset($request->discount_percentage)) {
                    $discountPercent = $product->discount_percentage = $request->discount_percentage;
                    $product->discount_amount = null;
                    $discountAmount = $product->price * ($discountPercent / 100);
                    $salePrice = $request->price - $discountAmount;
                    $product->sale_price = $salePrice;
                }   
                
            } else {
                $product->sale_price = $request->sale_price;
            }
            
            if(isset($request->special_image) && $request->special_offer == "on") {
                if ($request->has('special_image')) {
                    $product->special_offer = $request->special_offer;
                    $special_image = $request->file( 'special_image' );  
                    $special_imageType = $special_image->getClientOriginalExtension();
                    $special_imageStr = (string) Image::make( $special_image )->
                                            resize( 350, 350, function ( $constraint ) {
                                                $constraint->aspectRatio();
                                            })->encode( $special_imageType );
    
                    $product->special_image = base64_encode( $special_imageStr );
                    $product->special_image_type = $special_imageType;
                }
            } else {
                $product->special_offer = null;
                $product->special_image = null;
                $product->special_image_type = null;
            }

            $product->meta_title = $request->meta_title;

            if ($request->has('pre_meta_tags') && isset($request->pre_meta_tags) && $request->has('hidden_meta_tags') && isset($request->hidden_meta_tags)) { 
                $product->meta_tags = json_encode(explode(",",$request->pre_meta_tags.','.$request->hidden_meta_tags));
            } elseif ($request->has('hidden_meta_tags') && isset($request->hidden_meta_tags)) {
                $product->meta_tags = json_encode(explode(",",$request->hidden_meta_tags));
            } elseif ($request->has('pre_meta_tags') && isset($request->pre_meta_tags)) {
                $product->meta_tags = json_encode(explode(",",$request->pre_meta_tags));
            } else {
                $product->meta_tags = $product->meta_tags;
            }
            
            $product->meta_description = $request->meta_description;

            if($product->save()) {
                $product->categories()->attach($request->category_id);
                Session::flash('message','Product has been updated successfully.');
            } else {
                Session::flash('warning','Something is wrong when updating product.');
            }
            return redirect()->route('product.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product->delete();
        $product->categories()->detach($product);
        return redirect()->route('product.index');
    }
}
