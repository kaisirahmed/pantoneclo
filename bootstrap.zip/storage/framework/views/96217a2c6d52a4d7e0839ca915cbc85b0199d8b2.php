<div class="container-fluid page__heading-container">
    <div class="page__heading d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-lg-between text-center text-lg-left">
        <h6 class="m-lg-0"><?php echo $__env->yieldContent('title'); ?></h6>
        
    </div>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/admin/components/breadcrumbs/breadcrumbs.blade.php ENDPATH**/ ?>