<!-- Main Nav Menu -->

<div class="main_nav_menu ml-auto">
    <ul class="standard_dropdown main_nav_dropdown">
        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fas fa-chevron-down"></i></a></li>
        <li>
            <a href="<?php echo e(route('shop')); ?>">Shop<i class="fas fa-chevron-down"></i></a>
        </li>
        
        <li><a href="contact.html">Contact<i class="fas fa-chevron-down"></i></a></li>
    </ul>
</div><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/partials/menu.blade.php ENDPATH**/ ?>