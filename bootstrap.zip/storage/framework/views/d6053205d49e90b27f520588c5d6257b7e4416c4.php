<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $__env->yieldContent('title'); ?></title>

<?php echo $__env->make('layouts.partials.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('style'); ?>

</head>

<body>

<div class="super_container">
	
	<!-- Header -->
	
	<header class="header">

		<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</header>
	
	<!-- Banner -->

	<?php echo $__env->yieldContent('banner'); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<!-- Recently Viewed -->

	<?php echo $__env->make('layouts.partials.recentlyviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Brands -->

	<?php echo $__env->make('layouts.partials.brands', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Newsletter -->

	<?php echo $__env->make('layouts.partials.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Footer -->

	<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Copyright -->

	<?php echo $__env->make('layouts.partials.copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<?php echo $__env->make('layouts.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>

</body>

</html>

<script>
$(function () {
  $.scrollUp({
    scrollName: 'scrollUp', // Element ID
    topDistance: '300', // Distance from top before showing element (px)
    topSpeed: 500, // Speed back to top (ms)
    animation: 'fade', // Fade, slide, none
    animationInSpeed: 1000, // Animation in speed (ms)
    animationOutSpeed: 1000, // Animation out speed (ms)
    scrollText: 'Scroll to top', // Text for element
    activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
  });
});
</script><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/layouts/app.blade.php ENDPATH**/ ?>