
<?php $__env->startSection('title','Pentoneclo'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner'); ?>
<!-- Carousel Start -->
<?php echo $__env->make('layouts.partials.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Carousel End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Adverts -->

<?php echo $__env->make('layouts.partials.adverts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Trends -->

<?php echo $__env->make('layouts.partials.trends', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Reviews -->

<?php echo $__env->make('layouts.partials.reviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Characteristics -->

<?php echo $__env->make('layouts.partials.characteristics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Deals of the week -->

<?php echo $__env->make('layouts.partials.featureddeals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Popular Categories -->

<?php echo $__env->make('layouts.partials.popularcategories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Banner -->

<?php echo $__env->make('layouts.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Hot New Arrivals -->

<?php echo $__env->make('layouts.partials.newarrivals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Best Sellers -->

<?php echo $__env->make('layouts.partials.bestsellers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/index.blade.php ENDPATH**/ ?>