
<?php $__env->startSection('title','Cart'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/cart_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/styles/cart_responsive.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Cart -->

<div class="cart_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <div class="cart_container">
                    <div class="cart_title">Shopping Cart</div>
                    <div class="cart_items">
                        <ul class="cart_list">
                                                    
                            <li class="cart_item clearfix">
                                
                                <div class="cart_item_info d-flex flex-md-row flex-column justify-content-between">
                                    <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Image</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Size</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">Total</th>
                                            <th scope="col">Action</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $cartitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                          <tr>
                                            <th scope="row"><?php echo e($key+1); ?></th>
                                            <td><div class="cart_item_image"><img src="<?php echo e($item->attributes->image); ?>" alt=""></div></td>
                                            <td><div class="cart_item_text"><p><?php echo e(mb_strimwidth($item->name,0,25,"...")); ?></p></div></td>
                                            <td><div class="cart_item_text"><?php echo e($item->attributes->size); ?></div></td>
                                            <td>
                                                <div class="product_quantity cart_item_text clearfix">
                                                    <strong>Qty: </strong>
                                                    <input id="quantity" name="quantity" type="text" pattern="[0-9]*" value="<?php echo e($item->quantity); ?>">
                                                    <div class="quantity_buttons">
                                                        <div id="quantity_inc_button" class="quantity_inc quantity_control"><i class="fas fa-chevron-up"></i></div>
                                                        <div id="quantity_dec_button" class="quantity_dec quantity_control"><i class="fas fa-chevron-down"></i></div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><div class="cart_item_text"><?php echo e($item->attributes->currency); ?><?php echo e($item->price); ?></div></td>
                                            <td><div class="cart_item_text"><?php echo e($item->attributes->currency); ?><?php echo e(number_format($item->price * $item->quantity,2)); ?></div></td>
                                            <td>
                                                <div class="cart_item_text">
                                                    <button class="btn btn-outline-danger"><i class="fa fa-trash"></i></button>
                                                    <button class="btn btn-outline-primary"><i class="fa fa-refresh"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                  
                                </div>
                            </li>
                            
                        </ul>
                    </div>
                    
                    <!-- Order Total -->
                    <div class="order_total">
                        <div class="order_total_content text-md-right">
                            <div class="order_total_title">Order Total:</div>
                            <div class="order_total_amount">&#36;<?php echo e($total); ?></div>
                        </div>
                    </div>

                    <div class="cart_buttons">
                        <button type="button" class="button cart_button_clear" onclick="clearCart()">Clear Cart</button>
                        <button type="button" class="button cart_button_checkout">Update Cart</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Pantoneclo\pantoneclo\resources\views/pantoneclo/cart.blade.php ENDPATH**/ ?>