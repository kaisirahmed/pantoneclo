<!-- Main Nav Menu -->

<div class="main_nav_menu ml-auto">
    <ul class="standard_dropdown main_nav_dropdown">
        <li><a href="{{ route('home') }}">Home<i class="fas fa-chevron-down"></i></a></li>
        <li>
            <a href="{{ route('shop') }}">Shop<i class="fas fa-chevron-down"></i></a>
        </li>
        {{-- <li class="hassubs">
            <a href="#">Featured Brands<i class="fas fa-chevron-down"></i></a>
            <ul>
                <li>
                    <a href="#">Menu Item<i class="fas fa-chevron-down"></i></a>
                    <ul>
                        <li><a href="#">Menu Item<i class="fas fa-chevron-down"></i></a></li>
                        <li><a href="#">Menu Item<i class="fas fa-chevron-down"></i></a></li>
                        <li><a href="#">Menu Item<i class="fas fa-chevron-down"></i></a></li>
                    </ul>
                </li>
                <li><a href="#">Menu Item<i class="fas fa-chevron-down"></i></a></li>
                <li><a href="#">Menu Item<i class="fas fa-chevron-down"></i></a></li>
                <li><a href="#">Menu Item<i class="fas fa-chevron-down"></i></a></li>
            </ul>
        </li>
        <li class="hassubs">
            <a href="#">Pages<i class="fas fa-chevron-down"></i></a>
            <ul>
                <li><a href="shop.html">Shop<i class="fas fa-chevron-down"></i></a></li>
                <li><a href="product.html">Product<i class="fas fa-chevron-down"></i></a></li>
                <li><a href="blog.html">Blog<i class="fas fa-chevron-down"></i></a></li>
                <li><a href="blog_single.html">Blog Post<i class="fas fa-chevron-down"></i></a></li>
                <li><a href="regular.html">Regular Post<i class="fas fa-chevron-down"></i></a></li>
                <li><a href="cart.html">Cart<i class="fas fa-chevron-down"></i></a></li>
                <li><a href="contact.html">Contact<i class="fas fa-chevron-down"></i></a></li>
            </ul>
        </li>
        <li><a href="blog.html">Blog<i class="fas fa-chevron-down"></i></a></li> --}}
        <li><a href="contact.html">Contact<i class="fas fa-chevron-down"></i></a></li>
    </ul>
</div>