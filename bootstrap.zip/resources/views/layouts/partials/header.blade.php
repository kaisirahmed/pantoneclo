<!-- Top Bar -->

@include('layouts.partials.topbar')

<!-- Header Main -->

@include('layouts.partials.headermain')

<!-- Main Navigation -->

@include('layouts.partials.navbar')

