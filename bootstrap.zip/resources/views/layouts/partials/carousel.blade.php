<div class="container-fluid p-0 wow fadeIn" data-wow-delay="0.1s">

    <div class="owl-carousel-item position-relative" data-dot="<img src='{{ asset('assets/img/carousel-1.jpg') }}'>">
        <img class="img-fluid carousel-img" height="200px" src="{{ asset('assets/img/carousel-1.jpg') }}" alt="">
        <div class="owl-carousel-inner">
            <div class="container">
                {{-- <div class="row justify-content-start">
                    <div class="col-6 col-lg-6 mt-4">
                        <div class="card">
                            <div class="card-body">
                                <h2 class="display-5 text-white animated slideInDown">Pantoneclo</h2>
                                <p class="fs-5 fw-medium text-black front-text mb-1 pb-3" style="color:black">We own majority of our
                                    supply chain allowing us to make apparel with respect for natural resources. 
                                    Like the water we use for dyeing which we treat till it’s clean enough to 
                                    return to nature. We are setting standard for sustainability throughout the whole 
                                    manufacturing process. We respect each individual involve in our business. We make 
                                    apparel with respect for earth resources and creatures, the one’s we hope to protect 
                                    and the one’s we are yet to meet.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-6 mt-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Company Details</h5>
                                <h5 class="text-black animated slideInDown pb-3">Matrix Design d.o.o.</h5>
                                <p class="fs-5 fw-medium text-black front-text mb-1 pb-3" style="color:black">
                                     <span>Address&nbsp;&nbsp;&nbsp;:&nbsp;Pokopališka 4, 3000 Celje, Slovenia</span><br>
                                     <span>Reg No&nbsp;&nbsp;&nbsp;:&nbsp;8878153000</span><br>
                                     <span>EORI NO &nbsp;&nbsp;&nbsp;:&nbsp;SI66403618</span><br>
                                     <span>Tax No&nbsp;&nbsp;&nbsp;:&nbsp;66403618</span><br>
                                     <span>VAT No&nbsp;&nbsp;&nbsp;:&nbsp;SI66403618</span>
                                </p>
                            </div>
                        </div>
                        
                    </div>
                </div> --}}
            </div>
        </div>
    </div>
</div>