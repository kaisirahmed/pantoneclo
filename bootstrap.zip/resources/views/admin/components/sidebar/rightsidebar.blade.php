<div class="sidebar sidebar-light sidebar-left" data-perfect-scrollbar>

    <small class="text-dark-gray px-3 py-1">
        <strong>Thursday, 28 Feb</strong>
    </small>

    <div class="list-group list-group-flush">

        <div class="list-group-item bg-light">
            <div class="row">
                <div class="col-auto d-flex flex-column">
                    <small>12:30 PM</small>
                    <small class="text-dark-gray">2 hrs</small>
                </div>
                <div class="col">
                    <div class="d-flex flex-column flex">
                        <a href="#" class="text-body"><strong class="text-15pt">Marketing Team Meeting</strong></a>

                        <small class="text-muted d-flex align-items-center"><i class="material-icons icon-16pt mr-1">location_on</i> 16845 Hicks Road</small>


                    </div>
                    <div class="avatar-group mt-2">

                        <div class="avatar avatar-xs">
                            <img src="assets/images/256_joao-silas-636453-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                        </div>

                        <div class="avatar avatar-xs">
                            <img src="assets/images/256_jeremy-banks-798787-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                        </div>

                        <div class="avatar avatar-xs">
                            <img src="assets/images/256_daniel-gaffey-1060698-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>

    <small class="text-dark-gray px-3 py-1">
        <strong>Wednesday, 27 Feb</strong>
    </small>

    <div class="list-group list-group-flush">

        <div class="list-group-item bg-light">
            <div class="row">
                <div class="col-auto d-flex flex-column">
                    <small>07:48 PM</small>
                    <small class="text-dark-gray">30 min</small>
                </div>
                <div class="col">
                    <div class="d-flex flex-column flex">
                        <a href="#" class="text-body"><strong class="text-15pt">Call Alex</strong></a>


                        <small class="text-muted d-flex align-items-center"><i class="material-icons icon-16pt mr-1">phone</i> 202-555-0131</small>

                    </div>



                </div>
            </div>
        </div>

    </div>

    <small class="text-dark-gray px-3 py-1">
        <strong>Tuesday, 26 Feb</strong>
    </small>

    <div class="list-group list-group-flush">

        <div class="list-group-item bg-light">
            <div class="row">
                <div class="col-auto d-flex flex-column">
                    <small>03:13 PM</small>
                    <small class="text-dark-gray">2 hrs</small>
                </div>
                <div class="col">
                    <div class="d-flex flex-column flex">
                        <a href="#" class="text-body"><strong class="text-15pt">Design Team Meeting</strong></a>

                        <small class="text-muted d-flex align-items-center"><i class="material-icons icon-16pt mr-1">location_on</i> 16845 Hicks Road</small>


                    </div>
                    <div class="avatar-group mt-2">

                        <div class="avatar avatar-xs">
                            <img src="assets/images/256_rsz_1andy-lee-642320-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                        </div>

                        <div class="avatar avatar-xs">
                            <img src="assets/images/256_michael-dam-258165-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                        </div>

                        <div class="avatar avatar-xs">
                            <img src="assets/images/256_luke-porter-261779-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                        </div>

                        <div class="avatar avatar-xs">
                            <img src="assets/images/stories/256_rsz_clem-onojeghuo-193397-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>

    <small class="text-dark-gray px-3 py-1">
        <strong>Monday, 25 Feb</strong>
    </small>

    <div class="list-group list-group-flush">

        <div class="list-group-item bg-light">
            <div class="row">
                <div class="col-auto d-flex flex-column">
                    <small>12:30 PM</small>
                    <small class="text-dark-gray">2 hrs</small>
                </div>
                <div class="col d-flex">
                    <div class="d-flex flex-column flex">
                        <a href="#" class="text-body"><strong class="text-15pt">Call Wendy</strong></a>


                        <small class="text-muted d-flex align-items-center"><i class="material-icons icon-16pt mr-1">phone</i> 202-555-0131</small>

                    </div>


                    <div class="avatar avatar-xs">
                        <img src="assets/images/256_michael-dam-258165-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                    </div>


                </div>
            </div>
        </div>

    </div>

</div>

